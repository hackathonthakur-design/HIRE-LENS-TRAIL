import { useState } from 'react';
import { Search, Bell, HelpCircle, ChevronRight, Command, X } from 'lucide-react';
import type { Page } from '../types';

interface TopNavProps {
  activePage: Page;
  onNavigate: (page: Page) => void;
}

const breadcrumbMap: Partial<Record<Page, { parent?: string; label: string }>> = {
  dashboard: { label: 'Dashboard' },
  jobs: { parent: 'Recruiting', label: 'Jobs' },
  ranking: { parent: 'Candidates', label: 'AI Ranking' },
  profile: { parent: 'Candidates', label: 'Candidate Profile' },
  comparison: { parent: 'Candidates', label: 'Comparison' },
  'jd-analyzer': { parent: 'Recruiting', label: 'JD Analyzer' },
  'talent-pool': { label: 'Talent Pool' },
  analytics: { label: 'Analytics' },
  'create-job': { parent: 'Jobs', label: 'Create Job' },
  settings: { parent: 'Workspace', label: 'Settings' },
  team: { parent: 'Workspace', label: 'Team' },
  integrations: { parent: 'Workspace', label: 'Integrations' },
};

export default function TopNav({ activePage, onNavigate }: TopNavProps) {
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchValue, setSearchValue] = useState('');
  const [notifications] = useState(3);
  const crumb = breadcrumbMap[activePage] ?? { label: activePage };

  return (
    <header className="h-14 flex items-center gap-4 px-4 bg-white border-b border-zinc-200 flex-none">
      {/* Breadcrumbs */}
      <div className="flex items-center gap-1.5 text-sm flex-1 min-w-0">
        {crumb.parent && (
          <>
            <span className="text-zinc-400 font-medium truncate">{crumb.parent}</span>
            <ChevronRight size={14} className="text-zinc-300 flex-none" />
          </>
        )}
        <span className="text-zinc-800 font-semibold truncate">{crumb.label}</span>
      </div>

      {/* Search */}
      <div className="flex items-center gap-2">
        {searchOpen ? (
          <div className="flex items-center gap-2 bg-zinc-50 border border-zinc-200 rounded-lg px-3 py-1.5 w-64 transition-all">
            <Search size={14} className="text-zinc-400 flex-none" />
            <input
              autoFocus
              value={searchValue}
              onChange={(e) => setSearchValue(e.target.value)}
              placeholder="Search candidates, jobs, skills..."
              className="flex-1 text-sm bg-transparent outline-none text-zinc-800 placeholder-zinc-400"
            />
            <button onClick={() => { setSearchOpen(false); setSearchValue(''); }}>
              <X size={14} className="text-zinc-400 hover:text-zinc-600" />
            </button>
          </div>
        ) : (
          <button
            onClick={() => setSearchOpen(true)}
            className="flex items-center gap-2 text-sm text-zinc-500 bg-zinc-50 hover:bg-zinc-100 border border-zinc-200 rounded-lg px-3 py-1.5 transition-colors"
          >
            <Search size={14} />
            <span className="hidden sm:block">Search...</span>
            <span className="hidden sm:flex items-center gap-0.5 ml-2 text-xs text-zinc-400 bg-white border border-zinc-200 rounded px-1 py-0.5 font-mono">
              <Command size={10} />K
            </span>
          </button>
        )}

        {/* Notifications */}
        <button className="relative size-8 flex items-center justify-center rounded-lg hover:bg-zinc-100 text-zinc-500 hover:text-zinc-700 transition-colors">
          <Bell size={16} />
          {notifications > 0 && (
            <span className="absolute top-1 right-1 size-3.5 bg-indigo-600 text-white text-[9px] font-bold rounded-full flex items-center justify-center">
              {notifications}
            </span>
          )}
        </button>

        {/* Help */}
        <button className="size-8 flex items-center justify-center rounded-lg hover:bg-zinc-100 text-zinc-500 hover:text-zinc-700 transition-colors">
          <HelpCircle size={16} />
        </button>

        {/* Profile */}
        <button className="flex items-center gap-2 rounded-lg hover:bg-zinc-50 px-1.5 py-1 transition-colors">
          <div className="size-7 rounded-full bg-gradient-to-br from-indigo-400 to-violet-500 flex items-center justify-center text-white text-xs font-semibold flex-none">
            AR
          </div>
          <span className="hidden md:block text-sm font-medium text-zinc-700">Alex</span>
        </button>
      </div>
    </header>
  );
}
