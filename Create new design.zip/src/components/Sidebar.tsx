import {
  LayoutDashboard, Briefcase, Users, Sparkles, FileText,
  Database, BarChart3, Settings, ChevronRight, LogOut,
  UsersRound, Plug, ChevronsLeft, ChevronsRight,
} from 'lucide-react';
import type { Page } from '../types';

interface SidebarProps {
  activePage: Page;
  onNavigate: (page: Page) => void;
  collapsed: boolean;
  onToggle: () => void;
}

const primaryNav = [
  { id: 'dashboard' as Page, label: 'Dashboard', icon: LayoutDashboard },
  { id: 'jobs' as Page, label: 'Jobs', icon: Briefcase },
  { id: 'ranking' as Page, label: 'Candidates', icon: Users },
  { id: 'ranking' as Page, label: 'AI Screening', icon: Sparkles, exact: true },
  { id: 'jd-analyzer' as Page, label: 'JD Analyzer', icon: FileText },
  { id: 'talent-pool' as Page, label: 'Talent Pool', icon: Database },
  { id: 'analytics' as Page, label: 'Analytics', icon: BarChart3 },
];

const workspaceNav = [
  { id: 'team' as Page, label: 'Team', icon: UsersRound },
  { id: 'integrations' as Page, label: 'Integrations', icon: Plug },
  { id: 'settings' as Page, label: 'Settings', icon: Settings },
];

const isActive = (item: { id: Page; exact?: boolean }, activePage: Page) => {
  if (item.exact) return activePage === 'ranking' && item.label === 'AI Screening';
  if (item.label === 'Candidates') return activePage === 'ranking' || activePage === 'profile' || activePage === 'comparison';
  return activePage === item.id;
};

export default function Sidebar({ activePage, onNavigate, collapsed, onToggle }: SidebarProps) {
  return (
    <aside
      className={`flex flex-col bg-white border-r border-zinc-200 transition-all duration-200 flex-none ${collapsed ? 'w-14' : 'w-56'}`}
    >
      {/* Logo */}
      <div className={`flex items-center gap-2.5 h-14 px-3 border-b border-zinc-200 flex-none ${collapsed ? 'justify-center' : ''}`}>
        <div className="flex-none size-7 rounded-lg bg-indigo-600 flex items-center justify-center">
          <Sparkles size={14} className="text-white" />
        </div>
        {!collapsed && (
          <span className="text-sm font-semibold text-zinc-900 tracking-tight">HireLens AI</span>
        )}
        {!collapsed && (
          <button
            onClick={onToggle}
            className="ml-auto p-1 rounded hover:bg-zinc-100 text-zinc-400 hover:text-zinc-600 transition-colors"
          >
            <ChevronsLeft size={14} />
          </button>
        )}
        {collapsed && (
          <button
            onClick={onToggle}
            className="p-1 rounded hover:bg-zinc-100 text-zinc-400 hover:text-zinc-600 transition-colors"
          >
            <ChevronsRight size={14} />
          </button>
        )}
      </div>

      {/* Primary nav */}
      <nav className="flex-1 py-3 px-2 overflow-y-auto space-y-0.5">
        {primaryNav.map((item) => {
          const active = isActive(item, activePage);
          const Icon = item.icon;
          return (
            <button
              key={`${item.id}-${item.label}`}
              onClick={() => onNavigate(item.id)}
              title={collapsed ? item.label : undefined}
              className={`w-full flex items-center gap-2.5 px-2 py-1.5 rounded-md text-sm font-medium transition-colors text-left ${
                active
                  ? 'bg-indigo-50 text-indigo-700'
                  : 'text-zinc-600 hover:bg-zinc-50 hover:text-zinc-900'
              } ${collapsed ? 'justify-center' : ''}`}
            >
              <Icon size={16} className="flex-none" />
              {!collapsed && <span>{item.label}</span>}
              {!collapsed && active && <ChevronRight size={12} className="ml-auto text-indigo-400" />}
            </button>
          );
        })}

        {/* Workspace section */}
        <div className={`pt-4 pb-1 ${collapsed ? '' : ''}`}>
          {!collapsed && (
            <p className="px-2 text-[10px] font-semibold uppercase tracking-widest text-zinc-400 mb-1">
              Workspace
            </p>
          )}
          {collapsed && <div className="border-t border-zinc-200 mb-2" />}
          {workspaceNav.map((item) => {
            const active = activePage === item.id;
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                onClick={() => onNavigate(item.id)}
                title={collapsed ? item.label : undefined}
                className={`w-full flex items-center gap-2.5 px-2 py-1.5 rounded-md text-sm font-medium transition-colors text-left ${
                  active
                    ? 'bg-indigo-50 text-indigo-700'
                    : 'text-zinc-600 hover:bg-zinc-50 hover:text-zinc-900'
                } ${collapsed ? 'justify-center' : ''}`}
              >
                <Icon size={16} className="flex-none" />
                {!collapsed && <span>{item.label}</span>}
              </button>
            );
          })}
        </div>
      </nav>

      {/* User section */}
      <div className={`border-t border-zinc-200 p-2 flex-none`}>
        <div className={`flex items-center gap-2.5 p-1.5 rounded-md hover:bg-zinc-50 cursor-pointer group ${collapsed ? 'justify-center' : ''}`}>
          <div className="flex-none size-7 rounded-full bg-gradient-to-br from-indigo-400 to-violet-500 flex items-center justify-center text-white text-xs font-semibold">
            AR
          </div>
          {!collapsed && (
            <div className="flex-1 min-w-0">
              <p className="text-xs font-semibold text-zinc-900 truncate">Alex Rivera</p>
              <p className="text-[10px] text-zinc-500 truncate">Senior Recruiter</p>
            </div>
          )}
          {!collapsed && (
            <LogOut size={12} className="flex-none text-zinc-300 group-hover:text-zinc-500 transition-colors" />
          )}
        </div>
      </div>
    </aside>
  );
}
