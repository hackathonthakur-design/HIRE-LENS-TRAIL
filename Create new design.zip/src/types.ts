export type Page =
  | 'dashboard'
  | 'jobs'
  | 'ranking'
  | 'profile'
  | 'comparison'
  | 'jd-analyzer'
  | 'talent-pool'
  | 'analytics'
  | 'create-job'
  | 'settings'
  | 'team'
  | 'integrations';

export type CandidateStatus = 'new' | 'ai-screened' | 'shortlisted' | 'interview' | 'offer' | 'hired' | 'rejected';
export type JobStatus = 'hiring' | 'paused' | 'closed' | 'draft';

export interface Candidate {
  id: string;
  name: string;
  initials: string;
  color: string;
  currentRole: string;
  company: string;
  location: string;
  email: string;
  phone: string;
  linkedin: string;
  aiScore: number;
  experienceYears: number;
  skills: string[];
  status: CandidateStatus;
  appliedDate: string;
  source: string;
  salary: string;
  noticePeriod: string;
  summary: string;
  education: { degree: string; school: string; year: string }[];
  experience: { role: string; company: string; duration: string; description: string }[];
}

export interface Job {
  id: string;
  title: string;
  department: string;
  location: string;
  type: string;
  status: JobStatus;
  candidates: number;
  qualified: number;
  interviewing: number;
  offers: number;
  createdAt: string;
  salary: string;
}
