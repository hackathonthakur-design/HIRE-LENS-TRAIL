Redesign and significantly upgrade this entire AI-powered Applicant Tracking System (ATS) into a **premium, modern, production-ready SaaS recruitment platform**.

The existing product already contains screens for:

* Login / Authentication
* Recruiter Dashboard
* Candidate Ranking
* Candidate Profile
* Candidate Profile AI Analysis
* Candidate Comparison
* Job Description Analysis
* Create Job
* Recruitment Analytics
* Talent / Candidate Management

Do NOT simply change colors or typography. **Re-think the complete UX, information architecture, visual hierarchy, interactions, and component system.**

## PRODUCT VISION

Create a product that feels like a combination of:
**Linear + Notion + Stripe + Ramp + modern AI recruiting software**

The interface should communicate:

* Intelligence
* Trust
* Speed
* Professional recruitment
* Data-driven decision making
* AI assistance
* Enterprise quality

The final design should look like a **real startup product ready for investors, recruiters, HR teams, and enterprise customers.**

---

# 1. DESIGN SYSTEM

Create a complete reusable Figma design system.

### Typography

Use a modern professional sans-serif such as:

* Inter
* Geist
* SF Pro

Use strong typography hierarchy:

* Large page titles
* Clear section headings
* Compact metadata
* Highly readable body text
* Strong numerical emphasis for analytics

### Color System

Use a sophisticated light-first interface.

Primary:

* Deep navy / near-black for important text
* Electric blue / indigo for primary actions
* Subtle violet accents for AI functionality

Supporting:

* Green = positive / shortlisted / strong match
* Amber = warning / needs review
* Red = rejected / critical
* Neutral gray scale for surfaces and borders

AI functionality should have a **distinct but subtle visual identity**, such as a violet/blue gradient accent.

Avoid excessive gradients.

Use color primarily to communicate hierarchy and status.

---

# 2. GLOBAL APP SHELL

Create a consistent application shell across the entire platform.

### Left Sidebar

Include:

Logo:
**HireLens AI**

Navigation:

Dashboard
Jobs
Candidates
AI Screening
JD Analyzer
Talent Pool
Analytics

Then:

Workspace

* Team
* Integrations
* Settings

Bottom:

* User avatar
* User name
* Recruiter role
* Workspace selector

The sidebar should be:

* Compact
* Elegant
* Collapsible
* Icon + label
* Clear active state

---

# 3. TOP NAVIGATION

Create a professional top navigation area containing:

* Breadcrumbs
* Current page title
* Global search
* Notifications
* Help
* Recruiter profile

Global search should support:

"Search candidates, jobs, skills..."

Include keyboard shortcut:
⌘ K / Ctrl K

---

# 4. DASHBOARD

Completely redesign the recruiter dashboard.

Hero section:

"Good morning, Alex 👋"

Subtitle:

"Here’s what’s happening with your hiring pipeline."

Primary CTA:

"+ Create Job"

Secondary:

"Import Candidates"

### KPI CARDS

Show:

Open Positions
24

Total Candidates
1,284

Shortlisted
186

Interviews
72

Time to Hire
18 days

Each KPI card should include:

* Current value
* Previous period comparison
* Percentage change
* Small visualization
* Contextual icon

Example:

+18.4%
vs last month

---

# 5. RECRUITMENT PIPELINE

Create a beautiful hiring funnel visualization:

Applied
↓
AI Screened
↓
Shortlisted
↓
Interview
↓
Offer
↓
Hired

Each stage should display:

* Candidate count
* Conversion rate
* Average processing time

Allow clicking each stage to filter candidates.

---

# 6. AI INSIGHTS

Create a premium AI Insights card.

Title:

"AI Hiring Insights"

Example insights:

"12 candidates are strong matches but haven't been reviewed."

"Your Backend Engineer role has 34% fewer qualified candidates than similar roles."

"3 candidates have overlapping interview schedules."

Use an AI sparkle icon.

Add CTA:

"View AI Insights"

---

# 7. ACTIVE JOBS

Create a modern jobs table.

Columns:

Job
Candidates
Qualified
Interviewing
Status
Created
Actions

Each job should have:

Job title
Department
Location
Employment type

Example:

Senior Frontend Engineer
Engineering · Remote

Show candidate progress using mini progress bars.

Status badges:

Hiring
Paused
Closed
Draft

Add filters:

All
Active
Paused
Closed

Search and sorting.

---

# 8. CANDIDATE RANKING

This is one of the most important screens.

Create an advanced AI candidate ranking experience.

Header:

"Senior Frontend Engineer"

Subtext:

"128 candidates analyzed by HireLens AI"

Top statistics:

128 Applicants
42 Qualified
18 Strong Matches
7 Top Candidates

### AI RANKING TABLE

Columns:

Rank
Candidate
AI Match
Experience
Skills
Location
Status
Actions

Example:

#01
Sarah Chen

96% Match

8 yrs

React · TypeScript · Next.js

Strong Match

Use a visually prominent circular AI score.

Score ranges:

90–100 = Exceptional
80–89 = Strong
70–79 = Good
60–69 = Consider
<60 = Low Match

---

# 9. AI MATCH EXPLANATION

When clicking a candidate, show a detailed AI explanation.

Example:

"Why Sarah is a 96% match"

Strong matches:
✓ 7+ years React experience
✓ Advanced TypeScript
✓ Next.js production experience
✓ Relevant SaaS background

Potential gaps:
△ Limited AWS experience

AI recommendation:

"Highly recommended for technical interview."

Make this section highly trustworthy and transparent.

Never make AI look like a black box.

---

# 10. CANDIDATE PROFILE

Create an exceptional candidate profile page.

Header:

Candidate photo/avatar
Name
Current position
Location
Email
Phone
LinkedIn

Primary actions:

Shortlist
Reject
Move to Interview
Send Email

Display:

AI Match Score
96%

Experience
8 years

Skills
14

Education
3

---

# 11. CANDIDATE PROFILE SECTIONS

Use tabs:

Overview
Resume
AI Analysis
Experience
Skills
Education
Interviews
Activity

### Overview

Show:

Professional Summary
Work Experience
Top Skills
Education
Certifications

---

# 12. AI CANDIDATE ANALYSIS

Create a highly visual AI analysis screen.

Header:

"AI Candidate Analysis"

Display:

Overall Match
96%

Then:

Skills Match
94%

Experience Match
98%

Education Match
91%

Culture / Role Fit
93%

Create elegant horizontal progress indicators.

---

# 13. AI EXPLANATION

Include:

"Why this candidate matches"

with detailed reasoning.

Sections:

Strengths
Potential Concerns
Missing Requirements
Relevant Experience
Recommended Interview Questions

Add:

"Generate Interview Questions"

button.

---

# 14. CANDIDATE COMPARISON

Create a side-by-side candidate comparison interface.

Allow:

Select up to 4 candidates.

Comparison categories:

Overall Match
Experience
Technical Skills
Education
Industry Experience
Salary Expectation
Location
Notice Period

Highlight the strongest candidate in each category.

At the bottom:

"AI Recommendation"

Example:

"Candidate A is the strongest overall match due to deeper experience with your required technology stack."

CTA:

"Shortlist Recommended Candidate"

---

# 15. JOB DESCRIPTION ANALYZER

Create an AI-powered JD analysis interface.

Split screen:

LEFT:
Job Description editor

RIGHT:
AI Analysis

Analyze:

Required Skills
Preferred Skills
Experience
Education
Responsibilities
Potential Bias
Missing Information

Display:

JD Quality Score
92/100

AI suggestions:

"Consider specifying expected experience with React Server Components."

CTA:

"Improve Job Description"

---

# 16. CREATE JOB

Create a beautiful multi-step job creation flow.

Step indicator:

01 Basics
02 Description
03 Requirements
04 Screening
05 Review

Fields:

Job Title
Department
Location
Employment Type
Salary Range
Experience
Description
Responsibilities
Required Skills
Preferred Skills

AI feature:

"Generate with AI"

Allow recruiter to enter:

"Senior React developer for a fintech startup"

and automatically generate a complete job description.

---

# 17. ANALYTICS

Create a sophisticated recruitment analytics dashboard.

Include:

Time to Hire
Cost per Hire
Candidate Conversion
Source Performance
Hiring Funnel
Offer Acceptance
Diversity of Candidate Sources
Recruiter Performance

Charts should be:

* Minimal
* Clean
* Interactive
* Easy to understand

Add filters:

Date
Department
Recruiter
Location
Job

Include export button:

"Export Report"

---

# 18. TALENT POOL

Create a powerful candidate database.

Features:

Search
Filters
Saved searches
Tags
Skills
Experience
Location
Availability
AI Score

Allow recruiters to create:

"Frontend Experts"
"High Potential"
"Previously Interviewed"
"Silver Medalists"

candidate groups.

---

# 19. EMPTY STATES

Every major screen must have a polished empty state.

Do not leave blank screens.

Example:

"No candidates yet"

"Upload resumes or connect your hiring source to start screening candidates with AI."

CTA:

"Upload Candidates"

---

# 20. LOADING STATES

Design skeleton loaders for:

Candidate cards
Tables
Analytics
AI analysis
Dashboard statistics

AI processing state should say:

"Analyzing candidate..."

with subtle animated AI indicator.

---

# 21. MODALS AND DRAWERS

Create reusable:

Confirmation modal
Candidate quick view
AI explanation drawer
Add candidate modal
Create job modal
Reject candidate modal
Schedule interview modal

Use consistent spacing and buttons.

---

# 22. MICRO INTERACTIONS

Add premium micro-interactions:

* Smooth hover states
* Button press states
* Table row hover
* Animated AI score
* Progress animations
* Toast notifications
* Skeleton loading
* Smooth drawer transitions
* Tooltip interactions

Keep animations subtle and professional.

---

# 23. RESPONSIVE DESIGN

Design for:

Desktop
1440px
1280px
1024px

Tablet
768px

Mobile
390px

The desktop experience should be the primary experience, but all layouts must gracefully adapt.

---

# 24. ACCESSIBILITY

Follow strong accessibility principles:

WCAG-friendly contrast
Keyboard navigation
Clear focus states
Readable typography
Large enough click targets
Do not rely only on color to communicate status.

---

# 25. COMPONENT LIBRARY

Create reusable Figma components:

Buttons
Inputs
Dropdowns
Search
Tabs
Cards
Tables
Badges
Avatars
Progress bars
AI score
Charts
Tooltips
Dropdown menus
Modals
Drawers
Toast notifications
Pagination
Breadcrumbs
Sidebar
Navbar

Create variants for:

Default
Hover
Active
Disabled
Loading
Error
Success

---

# 26. VISUAL STYLE

The final product should feel:

Premium
Minimal
Modern
Intelligent
Fast
Trustworthy
Enterprise-ready

Avoid:

❌ Generic dashboard templates
❌ Excessive rounded cards
❌ Excessive gradients
❌ Neon colors
❌ Overloaded screens
❌ Tiny text
❌ Unnecessary decorative graphics
❌ Generic stock illustrations

Prefer:

✓ Strong hierarchy
✓ Generous whitespace
✓ Dense but readable data presentation
✓ Excellent tables
✓ Clear AI explanations
✓ Consistent spacing
✓ Professional enterprise SaaS aesthetics

---

# 27. IMPORTANT UX PRINCIPLE

The recruiter should understand what to do within **3 seconds** of opening every screen.

Every page must have:

1. Clear page title
2. Clear purpose
3. Primary action
4. Important metrics
5. Relevant content
6. Secondary actions hidden until needed

Reduce cognitive load.

---

# 28. FINAL FIGMA DELIVERABLE

Create a complete Figma-ready product system containing:

1. Design System
2. Components
3. Login
4. Dashboard
5. Jobs
6. Create Job
7. JD Analyzer
8. Candidate Ranking
9. Candidate Profile
10. AI Candidate Analysis
11. Candidate Comparison
12. Talent Pool
13. Analytics
14. Settings
15. Empty States
16. Loading States
17. Modals
18. Responsive layouts

Use **Auto Layout everywhere appropriate**.

Use **Figma variables/design tokens** for:

* Colors
* Typography
* Spacing
* Radius
* Shadows
* Component states

Maintain consistent spacing based on an **8px grid system**.

Make the result feel like a polished **2026 AI-native recruitment SaaS product**, not a generic ATS template.

The most important goal is:

**Make recruiters feel that HireLens AI understands their hiring workflow and removes repetitive work.**

Design for clarity, speed, trust, and intelligent decision-making.
