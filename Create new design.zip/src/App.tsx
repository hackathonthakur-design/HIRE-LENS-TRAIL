import { useState } from 'react';
import Sidebar from './components/Sidebar';
import TopNav from './components/TopNav';
import Dashboard from './pages/Dashboard';
import JobsPage from './pages/JobsPage';
import CandidateRanking from './pages/CandidateRanking';
import CandidateProfile from './pages/CandidateProfile';
import CandidateComparison from './pages/CandidateComparison';
import JDAnalyzer from './pages/JDAnalyzer';
import CreateJob from './pages/CreateJob';
import Analytics from './pages/Analytics';
import TalentPool from './pages/TalentPool';
import type { Page } from './types';
import { Settings, Users, Plug } from 'lucide-react';

export default function App() {
  const [page, setPage] = useState<Page>('dashboard');
  const [candidateId, setCandidateId] = useState<string>('c1');
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);

  const navigate = (p: Page) => setPage(p);
  const selectCandidate = (id: string) => setCandidateId(id);

  return (
    <div className="flex h-full bg-zinc-50 font-sans overflow-hidden">
      <Sidebar
        activePage={page}
        onNavigate={navigate}
        collapsed={sidebarCollapsed}
        onToggle={() => setSidebarCollapsed(c => !c)}
      />

      <div className="flex flex-col flex-1 min-w-0 overflow-hidden">
        <TopNav activePage={page} onNavigate={navigate} />

        <main className="flex-1 overflow-y-auto p-6">
          {page === 'dashboard' && (
            <Dashboard onNavigate={navigate} />
          )}
          {page === 'jobs' && (
            <JobsPage onNavigate={navigate} />
          )}
          {page === 'ranking' && (
            <CandidateRanking onNavigate={navigate} onSelectCandidate={selectCandidate} />
          )}
          {page === 'profile' && (
            <CandidateProfile candidateId={candidateId} onNavigate={navigate} />
          )}
          {page === 'comparison' && (
            <CandidateComparison onNavigate={navigate} onSelectCandidate={selectCandidate} />
          )}
          {page === 'jd-analyzer' && (
            <JDAnalyzer />
          )}
          {page === 'create-job' && (
            <CreateJob onNavigate={navigate} />
          )}
          {page === 'analytics' && (
            <Analytics />
          )}
          {page === 'talent-pool' && (
            <TalentPool onNavigate={navigate} onSelectCandidate={selectCandidate} />
          )}
          {(page === 'settings' || page === 'team' || page === 'integrations') && (
            <PlaceholderPage page={page} />
          )}
        </main>
      </div>
    </div>
  );
}

function PlaceholderPage({ page }: { page: Page }) {
  const config: Record<string, { icon: React.ComponentType<any>; title: string; desc: string }> = {
    settings: { icon: Settings, title: 'Settings', desc: 'Manage your workspace, billing, and notification preferences.' },
    team: { icon: Users, title: 'Team', desc: 'Invite team members, manage roles and permissions.' },
    integrations: { icon: Plug, title: 'Integrations', desc: 'Connect your ATS with LinkedIn, Greenhouse, and 20+ other tools.' },
  };
  const { icon: Icon, title, desc } = config[page] ?? config.settings;

  return (
    <div className="max-w-md mx-auto mt-24 text-center">
      <div className="size-14 rounded-2xl bg-zinc-100 flex items-center justify-center mx-auto mb-4">
        <Icon size={24} className="text-zinc-400" />
      </div>
      <h1 className="text-xl font-bold text-zinc-900">{title}</h1>
      <p className="text-sm text-zinc-500 mt-2 leading-relaxed">{desc}</p>
      <div className="mt-6 grid grid-cols-1 gap-2">
        {[1, 2, 3].map(i => (
          <div key={i} className="h-12 skeleton rounded-xl" />
        ))}
      </div>
    </div>
  );
}
