import { useState } from 'react';
import { Plus, X, Sparkles, Check, Crown, ArrowRight } from 'lucide-react';
import { candidates } from '../data/mock';
import type { Page } from '../types';

interface ComparisonProps {
  onNavigate: (page: Page) => void;
  onSelectCandidate: (id: string) => void;
}

const categories = [
  { key: 'overall', label: 'Overall Match', format: (c: typeof candidates[0]) => `${c.aiScore}%` },
  { key: 'experience', label: 'Experience', format: (c: typeof candidates[0]) => `${c.experienceYears} yrs` },
  { key: 'skills', label: 'Technical Skills', format: (c: typeof candidates[0]) => `${c.skills.length} skills` },
  { key: 'salary', label: 'Salary Expectation', format: (c: typeof candidates[0]) => c.salary },
  { key: 'location', label: 'Location', format: (c: typeof candidates[0]) => c.location.split(',')[0] },
  { key: 'notice', label: 'Notice Period', format: (c: typeof candidates[0]) => c.noticePeriod },
  { key: 'source', label: 'Source', format: (c: typeof candidates[0]) => c.source },
];

function isBest(key: string, candidates: typeof import('../data/mock').candidates, idx: number): boolean {
  if (candidates.length < 2) return false;
  const vals = candidates.map(c => {
    if (key === 'overall') return c.aiScore;
    if (key === 'experience') return c.experienceYears;
    if (key === 'skills') return c.skills.length;
    return 0;
  });
  if (vals.every(v => v === 0)) return false;
  return vals[idx] === Math.max(...vals);
}

export default function CandidateComparison({ onNavigate, onSelectCandidate }: ComparisonProps) {
  const [selectedIds, setSelectedIds] = useState<string[]>(['c1', 'c2', 'c3']);
  const [addOpen, setAddOpen] = useState(false);

  const selected = selectedIds.map(id => candidates.find(c => c.id === id)!).filter(Boolean);
  const topCandidate = [...selected].sort((a, b) => b.aiScore - a.aiScore)[0];

  const toggle = (id: string) => {
    if (selectedIds.includes(id)) {
      setSelectedIds(prev => prev.filter(x => x !== id));
    } else if (selectedIds.length < 4) {
      setSelectedIds(prev => [...prev, id]);
    }
  };

  return (
    <div className="max-w-[1280px] mx-auto space-y-5 fade-in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-zinc-900 tracking-tight">Candidate Comparison</h1>
          <p className="text-sm text-zinc-500 mt-0.5">Compare up to 4 candidates side by side</p>
        </div>
        <button
          onClick={() => setAddOpen(!addOpen)}
          className="flex items-center gap-1.5 px-3 py-2 text-sm font-medium text-zinc-700 bg-white border border-zinc-200 rounded-lg hover:bg-zinc-50 transition-colors"
        >
          <Plus size={14} />
          Add Candidate
        </button>
      </div>

      {/* Candidate picker */}
      {addOpen && (
        <div className="bg-white border border-zinc-200 rounded-xl p-4 fade-in">
          <p className="text-xs font-semibold text-zinc-500 uppercase tracking-wide mb-3">Select candidates to compare ({selectedIds.length}/4)</p>
          <div className="grid grid-cols-4 gap-2">
            {candidates.map((c) => {
              const isSelected = selectedIds.includes(c.id);
              return (
                <button
                  key={c.id}
                  onClick={() => toggle(c.id)}
                  disabled={!isSelected && selectedIds.length >= 4}
                  className={`flex items-center gap-2 p-2.5 rounded-lg border text-left transition-all ${
                    isSelected
                      ? 'border-indigo-300 bg-indigo-50'
                      : 'border-zinc-200 hover:border-zinc-300 hover:bg-zinc-50 disabled:opacity-40 disabled:cursor-not-allowed'
                  }`}
                >
                  <div className={`size-7 rounded-full flex items-center justify-center text-xs font-bold flex-none ${c.color}`}>
                    {c.initials}
                  </div>
                  <div className="min-w-0">
                    <p className="text-xs font-semibold text-zinc-900 truncate">{c.name}</p>
                    <p className="text-[10px] text-zinc-400 truncate">{c.aiScore}% match</p>
                  </div>
                  {isSelected && <Check size={12} className="ml-auto text-indigo-600 flex-none" />}
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* Comparison Table */}
      {selected.length > 0 ? (
        <div className="bg-white border border-zinc-200 rounded-xl overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-zinc-100">
                <th className="text-left px-5 py-3 text-xs font-semibold text-zinc-400 uppercase tracking-wide w-44">
                  Category
                </th>
                {selected.map((c) => (
                  <th key={c.id} className="px-4 py-3 text-center">
                    <div className="flex flex-col items-center gap-1.5">
                      <div className="relative">
                        <div className={`size-9 rounded-full flex items-center justify-center text-sm font-bold ${c.color}`}>
                          {c.initials}
                        </div>
                        {topCandidate?.id === c.id && selected.length > 1 && (
                          <div className="absolute -top-1 -right-1 size-4 bg-amber-400 rounded-full flex items-center justify-center">
                            <Crown size={9} className="text-white" />
                          </div>
                        )}
                      </div>
                      <div>
                        <p className="text-xs font-semibold text-zinc-900">{c.name.split(' ')[0]}</p>
                        <p className="text-[10px] text-zinc-400">{c.company}</p>
                      </div>
                      <button
                        onClick={() => toggle(c.id)}
                        className="p-0.5 hover:bg-zinc-100 rounded text-zinc-300 hover:text-zinc-500 transition-colors"
                      >
                        <X size={10} />
                      </button>
                    </div>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-50">
              {categories.map((cat) => (
                <tr key={cat.key} className="hover:bg-zinc-50/50 transition-colors">
                  <td className="px-5 py-3.5 text-xs font-medium text-zinc-500">{cat.label}</td>
                  {selected.map((c, i) => {
                    const best = isBest(cat.key, selected, i);
                    return (
                      <td key={c.id} className={`px-4 py-3.5 text-center ${best ? 'bg-emerald-50/50' : ''}`}>
                        <div className="flex items-center justify-center gap-1.5">
                          <span className={`text-sm font-semibold font-mono ${best ? 'text-emerald-700' : 'text-zinc-700'}`}>
                            {cat.format(c)}
                          </span>
                          {best && selected.length > 1 && (
                            <span className="size-4 bg-emerald-100 rounded-full flex items-center justify-center">
                              <Check size={9} className="text-emerald-600" />
                            </span>
                          )}
                        </div>
                      </td>
                    );
                  })}
                </tr>
              ))}

              {/* Skills row */}
              <tr className="hover:bg-zinc-50/50 transition-colors">
                <td className="px-5 py-3.5 text-xs font-medium text-zinc-500">Key Skills</td>
                {selected.map((c) => (
                  <td key={c.id} className="px-4 py-3.5 text-center">
                    <div className="flex flex-wrap justify-center gap-1">
                      {c.skills.slice(0, 3).map((s) => (
                        <span key={s} className="px-1.5 py-0.5 bg-zinc-100 text-zinc-600 text-[10px] font-medium rounded">
                          {s}
                        </span>
                      ))}
                    </div>
                  </td>
                ))}
              </tr>
            </tbody>
          </table>
        </div>
      ) : (
        <div className="bg-white border border-zinc-200 rounded-xl p-16 text-center">
          <p className="text-sm text-zinc-500">Add candidates to start comparing</p>
        </div>
      )}

      {/* AI Recommendation */}
      {selected.length >= 2 && topCandidate && (
        <div className="bg-white border border-zinc-200 rounded-xl p-5">
          <div className="flex items-center gap-2 mb-3">
            <div className="size-7 rounded-lg bg-violet-100 flex items-center justify-center">
              <Sparkles size={14} className="text-violet-600" />
            </div>
            <h3 className="text-sm font-semibold text-zinc-900">AI Recommendation</h3>
          </div>
          <p className="text-sm text-zinc-600 leading-relaxed">
            <span className="font-semibold text-zinc-900">{topCandidate.name}</span> is the strongest overall match
            with a <span className="font-semibold text-indigo-600">{topCandidate.aiScore}% AI score</span> and{' '}
            {topCandidate.experienceYears} years of relevant experience. Their background at{' '}
            {topCandidate.company} demonstrates deep expertise in the required technology stack.
            The combination of technical depth and proven SaaS experience makes them the top recommendation.
          </p>
          <div className="flex items-center gap-2 mt-4">
            <button
              onClick={() => { onSelectCandidate(topCandidate.id); onNavigate('profile'); }}
              className="flex items-center gap-1.5 px-4 py-2 text-sm font-semibold text-white bg-indigo-600 rounded-lg hover:bg-indigo-700 transition-colors"
            >
              View {topCandidate.name.split(' ')[0]}'s Full Profile <ArrowRight size={14} />
            </button>
            <button className="flex items-center gap-1.5 px-4 py-2 text-sm font-semibold text-indigo-700 bg-indigo-50 hover:bg-indigo-100 rounded-lg transition-colors">
              Shortlist Recommended Candidate
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
