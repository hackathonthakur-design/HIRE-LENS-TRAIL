import { useState } from 'react';
import {
  Search, Filter, Plus, Users, Star, MapPin, Briefcase,
  ChevronRight, Tag, Sparkles, Mail, Eye,
} from 'lucide-react';
import { candidates, talentGroups } from '../data/mock';
import type { Page } from '../types';

interface TalentPoolProps {
  onNavigate: (page: Page) => void;
  onSelectCandidate: (id: string) => void;
}

const groupColors: Record<string, string> = {
  indigo: 'bg-indigo-50 text-indigo-700 ring-1 ring-indigo-200',
  emerald: 'bg-emerald-50 text-emerald-700 ring-1 ring-emerald-200',
  amber: 'bg-amber-50 text-amber-700 ring-1 ring-amber-200',
  violet: 'bg-violet-50 text-violet-700 ring-1 ring-violet-200',
};

const groupDots: Record<string, string> = {
  indigo: 'bg-indigo-400',
  emerald: 'bg-emerald-400',
  amber: 'bg-amber-400',
  violet: 'bg-violet-400',
};

const filters = ['All', 'React', 'TypeScript', 'Remote', '5+ years', 'Strong Match'];

function ScorePill({ score }: { score: number }) {
  const color = score >= 90 ? 'bg-indigo-50 text-indigo-700' : score >= 80 ? 'bg-violet-50 text-violet-700' : score >= 70 ? 'bg-sky-50 text-sky-700' : 'bg-zinc-100 text-zinc-600';
  return (
    <span className={`inline-flex items-center gap-1 px-1.5 py-0.5 rounded-md text-[10px] font-bold font-mono ${color}`}>
      <Sparkles size={8} />
      {score}%
    </span>
  );
}

export default function TalentPool({ onNavigate, onSelectCandidate }: TalentPoolProps) {
  const [search, setSearch] = useState('');
  const [activeFilters, setActiveFilters] = useState<string[]>([]);
  const [activeGroup, setActiveGroup] = useState<string | null>(null);
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');

  const toggleFilter = (f: string) => {
    setActiveFilters(prev => prev.includes(f) ? prev.filter(x => x !== f) : [...prev, f]);
  };

  const filtered = candidates.filter(c => {
    const matchesSearch = c.name.toLowerCase().includes(search.toLowerCase()) ||
      c.currentRole.toLowerCase().includes(search.toLowerCase()) ||
      c.skills.some(s => s.toLowerCase().includes(search.toLowerCase()));
    return matchesSearch;
  });

  return (
    <div className="max-w-[1280px] mx-auto space-y-5 fade-in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-zinc-900 tracking-tight">Talent Pool</h1>
          <p className="text-sm text-zinc-500 mt-0.5">{candidates.length} candidates in your database</p>
        </div>
        <div className="flex items-center gap-2">
          <button className="flex items-center gap-1.5 px-3 py-2 text-sm text-zinc-700 bg-white border border-zinc-200 rounded-lg hover:bg-zinc-50 transition-colors">
            <Plus size={14} />
            New Group
          </button>
          <button className="flex items-center gap-1.5 px-3 py-2 text-sm font-semibold text-white bg-indigo-600 rounded-lg hover:bg-indigo-700 transition-colors">
            <Plus size={14} />
            Add Candidate
          </button>
        </div>
      </div>

      <div className="flex gap-4">
        {/* Sidebar: groups */}
        <div className="w-52 flex-none space-y-3">
          <div className="bg-white border border-zinc-200 rounded-xl p-3">
            <p className="text-[10px] font-semibold uppercase tracking-widest text-zinc-400 mb-2.5 px-1">Saved Groups</p>
            <div className="space-y-1">
              <button
                onClick={() => setActiveGroup(null)}
                className={`w-full flex items-center justify-between px-2 py-1.5 rounded-md text-sm transition-colors ${!activeGroup ? 'bg-indigo-50 text-indigo-700 font-medium' : 'text-zinc-600 hover:bg-zinc-50'}`}
              >
                <span className="flex items-center gap-2">
                  <Users size={14} />
                  All Candidates
                </span>
                <span className="text-xs font-mono text-zinc-400">{candidates.length}</span>
              </button>
              {talentGroups.map((g) => (
                <button
                  key={g.id}
                  onClick={() => setActiveGroup(activeGroup === g.id ? null : g.id)}
                  className={`w-full flex items-center justify-between px-2 py-1.5 rounded-md text-sm transition-colors ${activeGroup === g.id ? `bg-${g.color}-50 text-${g.color}-700 font-medium` : 'text-zinc-600 hover:bg-zinc-50'}`}
                >
                  <span className="flex items-center gap-2">
                    <div className={`size-2 rounded-full ${groupDots[g.color]}`} />
                    <span className="text-xs">{g.name}</span>
                  </span>
                  <span className="text-xs font-mono text-zinc-400">{g.count}</span>
                </button>
              ))}
            </div>

            <div className="mt-3 pt-3 border-t border-zinc-100">
              <button className="w-full flex items-center gap-1.5 px-2 py-1.5 text-xs text-zinc-500 hover:text-zinc-700 hover:bg-zinc-50 rounded-md transition-colors">
                <Plus size={12} />
                Create Saved Search
              </button>
            </div>
          </div>

          {/* Tags filter */}
          <div className="bg-white border border-zinc-200 rounded-xl p-3">
            <p className="text-[10px] font-semibold uppercase tracking-widest text-zinc-400 mb-2.5 px-1">Quick Filters</p>
            <div className="flex flex-wrap gap-1.5">
              {filters.map((f) => {
                const active = activeFilters.includes(f);
                return (
                  <button
                    key={f}
                    onClick={() => toggleFilter(f)}
                    className={`flex items-center gap-1 px-2 py-1 text-[10px] font-medium rounded-md transition-all ${
                      active ? 'bg-indigo-100 text-indigo-700' : 'bg-zinc-100 text-zinc-500 hover:bg-zinc-200'
                    }`}
                  >
                    {active && <span>✓</span>}
                    {f}
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Main content */}
        <div className="flex-1 min-w-0 space-y-3">
          {/* Search + view toggle */}
          <div className="flex items-center gap-2">
            <div className="flex-1 relative">
              <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-400" />
              <input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search candidates, skills, companies..."
                className="w-full pl-9 pr-3 py-2 text-sm bg-white border border-zinc-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-200 transition-all"
              />
            </div>
            <button className="flex items-center gap-1.5 px-3 py-2 text-sm text-zinc-600 bg-white border border-zinc-200 rounded-lg hover:bg-zinc-50 transition-colors">
              <Filter size={14} />
              More Filters
            </button>
            <div className="flex items-center bg-zinc-100 rounded-lg p-1 gap-1">
              <button
                onClick={() => setViewMode('grid')}
                className={`px-2.5 py-1 text-xs font-medium rounded-md transition-all ${viewMode === 'grid' ? 'bg-white shadow-sm text-zinc-900' : 'text-zinc-500'}`}
              >
                Grid
              </button>
              <button
                onClick={() => setViewMode('list')}
                className={`px-2.5 py-1 text-xs font-medium rounded-md transition-all ${viewMode === 'list' ? 'bg-white shadow-sm text-zinc-900' : 'text-zinc-500'}`}
              >
                List
              </button>
            </div>
          </div>

          {/* Group badge */}
          {activeGroup && (
            <div className="flex items-center gap-2">
              {talentGroups.filter(g => g.id === activeGroup).map(g => (
                <span key={g.id} className={`flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium rounded-full ${groupColors[g.color]}`}>
                  <Tag size={10} /> {g.name}
                </span>
              ))}
            </div>
          )}

          {/* Grid view */}
          {viewMode === 'grid' ? (
            <div className="grid grid-cols-3 gap-3">
              {filtered.map((c) => (
                <div
                  key={c.id}
                  className="bg-white border border-zinc-200 rounded-xl p-4 hover:border-zinc-300 hover:shadow-sm transition-all cursor-pointer group"
                  onClick={() => { onSelectCandidate(c.id); onNavigate('profile'); }}
                >
                  <div className="flex items-start gap-3 mb-3">
                    <div className={`size-10 rounded-full flex items-center justify-center text-sm font-bold flex-none ${c.color}`}>
                      {c.initials}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-semibold text-zinc-900 group-hover:text-indigo-600 transition-colors truncate">{c.name}</p>
                      <p className="text-xs text-zinc-500 truncate">{c.currentRole}</p>
                    </div>
                    <ScorePill score={c.aiScore} />
                  </div>

                  <div className="space-y-1.5 mb-3">
                    <div className="flex items-center gap-1.5 text-[11px] text-zinc-400">
                      <Briefcase size={10} />
                      {c.company}
                    </div>
                    <div className="flex items-center gap-1.5 text-[11px] text-zinc-400">
                      <MapPin size={10} />
                      {c.location}
                    </div>
                  </div>

                  <div className="flex flex-wrap gap-1 mb-3">
                    {c.skills.slice(0, 3).map((s) => (
                      <span key={s} className="px-1.5 py-0.5 bg-zinc-100 text-zinc-600 text-[10px] font-medium rounded">
                        {s}
                      </span>
                    ))}
                    {c.skills.length > 3 && (
                      <span className="px-1.5 py-0.5 text-zinc-400 text-[10px]">+{c.skills.length - 3}</span>
                    )}
                  </div>

                  <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity pt-2 border-t border-zinc-100">
                    <button
                      onClick={(e) => e.stopPropagation()}
                      className="flex-1 flex items-center justify-center gap-1 py-1.5 text-[11px] text-zinc-500 hover:text-indigo-600 hover:bg-indigo-50 rounded-md transition-colors"
                    >
                      <Mail size={11} /> Email
                    </button>
                    <button
                      onClick={(e) => e.stopPropagation()}
                      className="flex-1 flex items-center justify-center gap-1 py-1.5 text-[11px] text-zinc-500 hover:text-amber-600 hover:bg-amber-50 rounded-md transition-colors"
                    >
                      <Star size={11} /> Save
                    </button>
                    <button className="flex-1 flex items-center justify-center gap-1 py-1.5 text-[11px] text-zinc-500 hover:text-zinc-800 hover:bg-zinc-100 rounded-md transition-colors">
                      <Eye size={11} /> View
                    </button>
                  </div>
                </div>
              ))}

              {/* Empty state */}
              {filtered.length === 0 && (
                <div className="col-span-3 flex flex-col items-center justify-center py-16 text-center">
                  <div className="size-12 rounded-full bg-zinc-100 flex items-center justify-center mb-3">
                    <Users size={20} className="text-zinc-400" />
                  </div>
                  <p className="text-sm font-medium text-zinc-600">No candidates found</p>
                  <p className="text-xs text-zinc-400 mt-1">Upload resumes or connect your hiring source</p>
                  <button className="mt-4 flex items-center gap-1.5 px-4 py-2 text-sm font-semibold text-white bg-indigo-600 rounded-lg hover:bg-indigo-700 transition-colors">
                    <Plus size={14} /> Add Candidates
                  </button>
                </div>
              )}
            </div>
          ) : (
            // List view
            <div className="bg-white border border-zinc-200 rounded-xl overflow-hidden">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-zinc-100 bg-zinc-50/50">
                    <th className="text-left px-5 py-3 text-xs font-semibold text-zinc-400 uppercase tracking-wide">Candidate</th>
                    <th className="text-left px-4 py-3 text-xs font-semibold text-zinc-400 uppercase tracking-wide">AI Score</th>
                    <th className="text-left px-4 py-3 text-xs font-semibold text-zinc-400 uppercase tracking-wide">Experience</th>
                    <th className="text-left px-4 py-3 text-xs font-semibold text-zinc-400 uppercase tracking-wide">Skills</th>
                    <th className="text-left px-4 py-3 text-xs font-semibold text-zinc-400 uppercase tracking-wide">Location</th>
                    <th className="px-4 py-3" />
                  </tr>
                </thead>
                <tbody className="divide-y divide-zinc-50">
                  {filtered.map((c) => (
                    <tr
                      key={c.id}
                      className="hover:bg-zinc-50/50 cursor-pointer transition-colors group"
                      onClick={() => { onSelectCandidate(c.id); onNavigate('profile'); }}
                    >
                      <td className="px-5 py-3">
                        <div className="flex items-center gap-2.5">
                          <div className={`size-8 rounded-full flex items-center justify-center text-xs font-bold flex-none ${c.color}`}>
                            {c.initials}
                          </div>
                          <div>
                            <p className="font-semibold text-zinc-900 group-hover:text-indigo-600 transition-colors">{c.name}</p>
                            <p className="text-[11px] text-zinc-400">{c.currentRole} · {c.company}</p>
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-3"><ScorePill score={c.aiScore} /></td>
                      <td className="px-4 py-3"><span className="text-xs font-mono text-zinc-700">{c.experienceYears} yrs</span></td>
                      <td className="px-4 py-3">
                        <div className="flex gap-1">
                          {c.skills.slice(0, 3).map(s => (
                            <span key={s} className="px-1.5 py-0.5 bg-zinc-100 text-zinc-600 text-[10px] font-medium rounded">{s}</span>
                          ))}
                        </div>
                      </td>
                      <td className="px-4 py-3"><span className="text-xs text-zinc-500">{c.location}</span></td>
                      <td className="px-4 py-3">
                        <ChevronRight size={14} className="text-zinc-300 group-hover:text-zinc-500 transition-colors" />
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
