import { useState } from 'react';
import { Plus, Search, Filter, MoreHorizontal, MapPin, Clock, DollarSign, Users, ArrowUpDown, Briefcase } from 'lucide-react';
import { jobs } from '../data/mock';
import type { Page, JobStatus } from '../types';

interface JobsPageProps {
  onNavigate: (page: Page) => void;
}

const statusConfig: Record<JobStatus, { label: string; cls: string }> = {
  hiring: { label: 'Hiring', cls: 'bg-emerald-50 text-emerald-700 ring-1 ring-emerald-200' },
  paused: { label: 'Paused', cls: 'bg-amber-50 text-amber-700 ring-1 ring-amber-200' },
  closed: { label: 'Closed', cls: 'bg-zinc-100 text-zinc-500 ring-1 ring-zinc-200' },
  draft: { label: 'Draft', cls: 'bg-zinc-50 text-zinc-400 ring-1 ring-zinc-200' },
};

const filters = ['All', 'Active', 'Paused', 'Closed', 'Draft'] as const;
type Filter = typeof filters[number];

export default function JobsPage({ onNavigate }: JobsPageProps) {
  const [activeFilter, setActiveFilter] = useState<Filter>('All');
  const [search, setSearch] = useState('');

  const filtered = jobs.filter((j) => {
    const matchesSearch = j.title.toLowerCase().includes(search.toLowerCase()) ||
      j.department.toLowerCase().includes(search.toLowerCase());
    const matchesFilter =
      activeFilter === 'All' ||
      (activeFilter === 'Active' && j.status === 'hiring') ||
      (activeFilter === 'Paused' && j.status === 'paused') ||
      (activeFilter === 'Closed' && j.status === 'closed') ||
      (activeFilter === 'Draft' && j.status === 'draft');
    return matchesSearch && matchesFilter;
  });

  return (
    <div className="max-w-[1280px] mx-auto space-y-5 fade-in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-zinc-900 tracking-tight">Jobs</h1>
          <p className="text-sm text-zinc-500 mt-0.5">{jobs.length} positions · {jobs.filter(j => j.status === 'hiring').length} actively hiring</p>
        </div>
        <button
          onClick={() => onNavigate('create-job')}
          className="flex items-center gap-1.5 px-3 py-2 text-sm font-semibold text-white bg-indigo-600 rounded-lg hover:bg-indigo-700 transition-colors"
        >
          <Plus size={14} />
          New Job
        </button>
      </div>

      {/* Filters + Search */}
      <div className="flex items-center gap-3">
        <div className="flex items-center gap-1 bg-zinc-100 rounded-lg p-1">
          {filters.map((f) => (
            <button
              key={f}
              onClick={() => setActiveFilter(f)}
              className={`px-3 py-1 text-xs font-medium rounded-md transition-all ${
                activeFilter === f
                  ? 'bg-white text-zinc-900 shadow-sm'
                  : 'text-zinc-500 hover:text-zinc-700'
              }`}
            >
              {f}
            </button>
          ))}
        </div>
        <div className="flex-1 relative">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-400" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search jobs..."
            className="w-full pl-9 pr-3 py-2 text-sm bg-white border border-zinc-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-200 focus:border-indigo-400 transition-all"
          />
        </div>
        <button className="flex items-center gap-1.5 px-3 py-2 text-sm text-zinc-600 bg-white border border-zinc-200 rounded-lg hover:bg-zinc-50 transition-colors">
          <Filter size={14} />
          Filter
        </button>
        <button className="flex items-center gap-1.5 px-3 py-2 text-sm text-zinc-600 bg-white border border-zinc-200 rounded-lg hover:bg-zinc-50 transition-colors">
          <ArrowUpDown size={14} />
          Sort
        </button>
      </div>

      {/* Table */}
      <div className="bg-white border border-zinc-200 rounded-xl overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-zinc-100 bg-zinc-50/50">
              <th className="text-left px-5 py-3 text-xs font-semibold text-zinc-400 uppercase tracking-wide">Job</th>
              <th className="text-left px-4 py-3 text-xs font-semibold text-zinc-400 uppercase tracking-wide">Candidates</th>
              <th className="text-left px-4 py-3 text-xs font-semibold text-zinc-400 uppercase tracking-wide">Qualified</th>
              <th className="text-left px-4 py-3 text-xs font-semibold text-zinc-400 uppercase tracking-wide">Interviewing</th>
              <th className="text-left px-4 py-3 text-xs font-semibold text-zinc-400 uppercase tracking-wide">Salary</th>
              <th className="text-left px-4 py-3 text-xs font-semibold text-zinc-400 uppercase tracking-wide">Status</th>
              <th className="text-left px-4 py-3 text-xs font-semibold text-zinc-400 uppercase tracking-wide">Created</th>
              <th className="px-4 py-3" />
            </tr>
          </thead>
          <tbody className="divide-y divide-zinc-50">
            {filtered.map((job) => {
              const cfg = statusConfig[job.status];
              const pct = job.candidates > 0 ? Math.round((job.qualified / job.candidates) * 100) : 0;
              return (
                <tr
                  key={job.id}
                  className="hover:bg-zinc-50/60 cursor-pointer transition-colors group"
                  onClick={() => onNavigate('ranking')}
                >
                  <td className="px-5 py-3.5">
                    <p className="font-semibold text-zinc-900 group-hover:text-indigo-600 transition-colors">{job.title}</p>
                    <div className="flex items-center gap-3 mt-1">
                      <span className="flex items-center gap-1 text-[11px] text-zinc-400">
                        <Users size={10} />
                        {job.department}
                      </span>
                      <span className="flex items-center gap-1 text-[11px] text-zinc-400">
                        <MapPin size={10} />
                        {job.location}
                      </span>
                      <span className="text-[11px] text-zinc-400">{job.type}</span>
                    </div>
                  </td>
                  <td className="px-4 py-3.5">
                    <span className="font-mono font-semibold text-zinc-800">{job.candidates}</span>
                  </td>
                  <td className="px-4 py-3.5">
                    <div className="flex items-center gap-2">
                      <div className="w-14 h-1.5 bg-zinc-100 rounded-full overflow-hidden">
                        <div className="h-full bg-emerald-400 rounded-full" style={{ width: `${pct}%` }} />
                      </div>
                      <span className="text-xs font-mono text-zinc-600">{job.qualified}</span>
                    </div>
                  </td>
                  <td className="px-4 py-3.5">
                    <span className="font-mono text-zinc-700">{job.interviewing}</span>
                  </td>
                  <td className="px-4 py-3.5">
                    <span className="flex items-center gap-1 text-xs text-zinc-600">
                      <DollarSign size={10} className="text-zinc-400" />
                      {job.salary}
                    </span>
                  </td>
                  <td className="px-4 py-3.5">
                    <span className={`inline-flex items-center px-2 py-0.5 rounded-md text-[11px] font-semibold ${cfg.cls}`}>
                      {cfg.label}
                    </span>
                  </td>
                  <td className="px-4 py-3.5">
                    <span className="flex items-center gap-1 text-xs text-zinc-400">
                      <Clock size={10} />
                      {new Date(job.createdAt).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                    </span>
                  </td>
                  <td className="px-4 py-3.5">
                    <button
                      className="opacity-0 group-hover:opacity-100 transition-opacity p-1 hover:bg-zinc-200 rounded"
                      onClick={(e) => e.stopPropagation()}
                    >
                      <MoreHorizontal size={14} className="text-zinc-400" />
                    </button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>

        {filtered.length === 0 && (
          <div className="flex flex-col items-center justify-center py-16 text-center">
            <div className="size-12 rounded-full bg-zinc-100 flex items-center justify-center mb-3">
              <Briefcase size={20} className="text-zinc-400" />
            </div>
            <p className="text-sm font-medium text-zinc-600">No jobs found</p>
            <p className="text-xs text-zinc-400 mt-1">Try adjusting your search or filters</p>
          </div>
        )}
      </div>
    </div>
  );
}
