import { useState } from 'react';
import {
  TrendingUp, TrendingDown, Users, Briefcase, Star, Calendar,
  Clock, Sparkles, Plus, Upload, ArrowRight, ChevronRight,
  MoreHorizontal,
} from 'lucide-react';
import { jobs, pipelineStages } from '../data/mock';
import type { Page } from '../types';

interface DashboardProps {
  onNavigate: (page: Page) => void;
}

const kpis = [
  {
    label: 'Open Positions',
    value: '24',
    delta: '+3',
    deltaLabel: 'vs last month',
    up: true,
    icon: Briefcase,
    iconBg: 'bg-indigo-50',
    iconColor: 'text-indigo-600',
  },
  {
    label: 'Total Candidates',
    value: '1,284',
    delta: '+18.4%',
    deltaLabel: 'vs last month',
    up: true,
    icon: Users,
    iconBg: 'bg-violet-50',
    iconColor: 'text-violet-600',
  },
  {
    label: 'Shortlisted',
    value: '186',
    delta: '+12',
    deltaLabel: 'this week',
    up: true,
    icon: Star,
    iconBg: 'bg-emerald-50',
    iconColor: 'text-emerald-600',
  },
  {
    label: 'Interviews',
    value: '72',
    delta: '+5',
    deltaLabel: 'scheduled',
    up: true,
    icon: Calendar,
    iconBg: 'bg-sky-50',
    iconColor: 'text-sky-600',
  },
  {
    label: 'Time to Hire',
    value: '18 days',
    delta: '-3 days',
    deltaLabel: 'vs last month',
    up: true,
    icon: Clock,
    iconBg: 'bg-amber-50',
    iconColor: 'text-amber-600',
  },
];

const insights = [
  '12 candidates are strong matches for Frontend Engineer but haven\'t been reviewed.',
  'Your Backend Engineer role has 34% fewer qualified candidates than similar roles.',
  '3 candidates have overlapping interview schedules this Thursday.',
];

const statusConfig = {
  hiring: { label: 'Hiring', cls: 'bg-emerald-50 text-emerald-700 ring-1 ring-emerald-200' },
  paused: { label: 'Paused', cls: 'bg-amber-50 text-amber-700 ring-1 ring-amber-200' },
  closed: { label: 'Closed', cls: 'bg-zinc-100 text-zinc-500 ring-1 ring-zinc-200' },
  draft: { label: 'Draft', cls: 'bg-zinc-50 text-zinc-400 ring-1 ring-zinc-200' },
};

export default function Dashboard({ onNavigate }: DashboardProps) {
  const [activeStage, setActiveStage] = useState<number | null>(null);
  const maxCount = pipelineStages[0].count;

  return (
    <div className="max-w-[1280px] mx-auto space-y-6 fade-in">
      {/* Hero */}
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-2xl font-bold text-zinc-900 tracking-tight">
            Good morning, Alex 👋
          </h1>
          <p className="mt-1 text-sm text-zinc-500">
            {"Here's what's happening with your hiring pipeline today."}
          </p>
        </div>
        <div className="flex items-center gap-2 flex-none">
          <button
            onClick={() => onNavigate('create-job')}
            className="flex items-center gap-1.5 px-3 py-2 text-sm font-medium text-zinc-700 bg-white border border-zinc-200 rounded-lg hover:bg-zinc-50 transition-colors"
          >
            <Upload size={14} />
            Import Candidates
          </button>
          <button
            onClick={() => onNavigate('create-job')}
            className="flex items-center gap-1.5 px-3 py-2 text-sm font-semibold text-white bg-indigo-600 rounded-lg hover:bg-indigo-700 transition-colors"
          >
            <Plus size={14} />
            Create Job
          </button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-5 gap-3">
        {kpis.map((kpi) => {
          const Icon = kpi.icon;
          return (
            <div key={kpi.label} className="bg-white border border-zinc-200 rounded-xl p-4 hover:border-zinc-300 transition-colors">
              <div className="flex items-center justify-between mb-3">
                <div className={`size-8 rounded-lg ${kpi.iconBg} flex items-center justify-center`}>
                  <Icon size={15} className={kpi.iconColor} />
                </div>
                {kpi.up ? (
                  <TrendingUp size={14} className="text-emerald-500" />
                ) : (
                  <TrendingDown size={14} className="text-red-500" />
                )}
              </div>
              <p className="text-2xl font-bold text-zinc-900 tracking-tight font-mono">{kpi.value}</p>
              <p className="text-xs text-zinc-500 mt-0.5">{kpi.label}</p>
              <div className="mt-2 flex items-center gap-1">
                <span className={`text-xs font-semibold ${kpi.up ? 'text-emerald-600' : 'text-red-500'}`}>
                  {kpi.delta}
                </span>
                <span className="text-xs text-zinc-400">{kpi.deltaLabel}</span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Pipeline + AI Insights */}
      <div className="grid grid-cols-3 gap-4">
        {/* Pipeline */}
        <div className="col-span-2 bg-white border border-zinc-200 rounded-xl p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-sm font-semibold text-zinc-900">Recruitment Pipeline</h2>
              <p className="text-xs text-zinc-500 mt-0.5">All active jobs · last 30 days</p>
            </div>
            <button
              onClick={() => onNavigate('ranking')}
              className="text-xs font-medium text-indigo-600 hover:text-indigo-700 flex items-center gap-1"
            >
              View candidates <ArrowRight size={12} />
            </button>
          </div>

          <div className="space-y-2.5">
            {pipelineStages.map((stage, i) => {
              const width = Math.round((stage.count / maxCount) * 100);
              const isSelected = activeStage === i;
              return (
                <button
                  key={stage.name}
                  onClick={() => setActiveStage(isSelected ? null : i)}
                  className={`w-full text-left p-2.5 rounded-lg transition-all ${isSelected ? 'bg-indigo-50 ring-1 ring-indigo-200' : 'hover:bg-zinc-50'}`}
                >
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="text-xs font-medium text-zinc-700">{stage.name}</span>
                    <div className="flex items-center gap-3">
                      {stage.time && (
                        <span className="text-[10px] text-zinc-400 font-mono">{stage.time} avg</span>
                      )}
                      {stage.rate !== null && (
                        <span className="text-[10px] text-zinc-500">{stage.rate}% conversion</span>
                      )}
                      <span className="text-xs font-bold text-zinc-900 font-mono w-12 text-right">{stage.count.toLocaleString()}</span>
                    </div>
                  </div>
                  <div className="h-1.5 bg-zinc-100 rounded-full overflow-hidden">
                    <div
                      className="h-full rounded-full transition-all duration-500"
                      style={{ width: `${width}%`, backgroundColor: stage.color }}
                    />
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* AI Insights */}
        <div className="bg-white border border-zinc-200 rounded-xl p-5 flex flex-col">
          <div className="flex items-center gap-2 mb-4">
            <div className="size-7 rounded-lg bg-violet-100 flex items-center justify-center">
              <Sparkles size={14} className="text-violet-600" />
            </div>
            <div>
              <h2 className="text-sm font-semibold text-zinc-900">AI Hiring Insights</h2>
              <p className="text-[10px] text-violet-500 font-medium">Powered by HireLens AI</p>
            </div>
          </div>

          <div className="space-y-3 flex-1">
            {insights.map((insight, i) => (
              <div key={i} className="flex gap-2.5">
                <div className="flex-none mt-0.5 size-1.5 rounded-full bg-violet-400" />
                <p className="text-xs text-zinc-600 leading-relaxed">{insight}</p>
              </div>
            ))}
          </div>

          <button
            onClick={() => onNavigate('ranking')}
            className="mt-4 w-full flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-semibold text-violet-700 bg-violet-50 hover:bg-violet-100 rounded-lg transition-colors"
          >
            View AI Insights <ArrowRight size={12} />
          </button>
        </div>
      </div>

      {/* Active Jobs */}
      <div className="bg-white border border-zinc-200 rounded-xl overflow-hidden">
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-zinc-100">
          <h2 className="text-sm font-semibold text-zinc-900">Active Jobs</h2>
          <button
            onClick={() => onNavigate('jobs')}
            className="text-xs font-medium text-indigo-600 hover:text-indigo-700 flex items-center gap-1"
          >
            View all jobs <ChevronRight size={12} />
          </button>
        </div>
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-zinc-100">
              {['Job', 'Candidates', 'Qualified', 'Interviewing', 'Status', ''].map((col) => (
                <th key={col} className="text-left px-5 py-2.5 text-xs font-medium text-zinc-400 whitespace-nowrap">
                  {col}
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-zinc-50">
            {jobs.filter(j => j.status !== 'closed').slice(0, 5).map((job) => {
              const cfg = statusConfig[job.status];
              const pct = job.candidates > 0 ? Math.round((job.qualified / job.candidates) * 100) : 0;
              return (
                <tr
                  key={job.id}
                  className="hover:bg-zinc-50/50 cursor-pointer transition-colors group"
                  onClick={() => onNavigate('ranking')}
                >
                  <td className="px-5 py-3">
                    <p className="font-medium text-zinc-900 group-hover:text-indigo-600 transition-colors">{job.title}</p>
                    <p className="text-xs text-zinc-400 mt-0.5">{job.department} · {job.location}</p>
                  </td>
                  <td className="px-5 py-3">
                    <span className="font-mono text-sm font-semibold text-zinc-800">{job.candidates}</span>
                  </td>
                  <td className="px-5 py-3">
                    <div className="flex items-center gap-2">
                      <div className="w-16 h-1.5 bg-zinc-100 rounded-full overflow-hidden">
                        <div className="h-full bg-emerald-400 rounded-full" style={{ width: `${pct}%` }} />
                      </div>
                      <span className="text-xs text-zinc-600 font-mono">{job.qualified}</span>
                    </div>
                  </td>
                  <td className="px-5 py-3">
                    <span className="font-mono text-sm text-zinc-700">{job.interviewing}</span>
                  </td>
                  <td className="px-5 py-3">
                    <span className={`inline-flex items-center px-2 py-0.5 rounded-md text-[11px] font-semibold ${cfg.cls}`}>
                      {cfg.label}
                    </span>
                  </td>
                  <td className="px-5 py-3">
                    <button className="opacity-0 group-hover:opacity-100 transition-opacity p-1 hover:bg-zinc-100 rounded">
                      <MoreHorizontal size={14} className="text-zinc-400" />
                    </button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
