import { useState } from 'react';
import {
  Search, Filter, ArrowUpDown, Sparkles, Star, Eye,
  ChevronRight, MapPin, X, Check, AlertTriangle, ArrowRight,
} from 'lucide-react';
import { candidates } from '../data/mock';
import type { Page, CandidateStatus } from '../types';

interface CandidateRankingProps {
  onNavigate: (page: Page) => void;
  onSelectCandidate: (id: string) => void;
}

const statusConfig: Record<CandidateStatus, { label: string; cls: string }> = {
  new: { label: 'New', cls: 'bg-zinc-100 text-zinc-500' },
  'ai-screened': { label: 'AI Screened', cls: 'bg-violet-50 text-violet-700' },
  shortlisted: { label: 'Shortlisted', cls: 'bg-indigo-50 text-indigo-700' },
  interview: { label: 'Interview', cls: 'bg-sky-50 text-sky-700' },
  offer: { label: 'Offer', cls: 'bg-emerald-50 text-emerald-700' },
  hired: { label: 'Hired', cls: 'bg-emerald-100 text-emerald-800' },
  rejected: { label: 'Rejected', cls: 'bg-red-50 text-red-600' },
};

function ScoreRing({ score }: { score: number }) {
  const r = 16;
  const circ = 2 * Math.PI * r;
  const fill = (score / 100) * circ;
  const color = score >= 90 ? '#4f46e5' : score >= 80 ? '#7c3aed' : score >= 70 ? '#0ea5e9' : score >= 60 ? '#f59e0b' : '#ef4444';
  const label = score >= 90 ? 'Exceptional' : score >= 80 ? 'Strong' : score >= 70 ? 'Good' : score >= 60 ? 'Consider' : 'Low Match';

  return (
    <div className="flex items-center gap-2.5">
      <div className="relative flex-none size-9">
        <svg viewBox="0 0 36 36" className="size-9 -rotate-90">
          <circle cx="18" cy="18" r={r} fill="none" stroke="#f4f4f5" strokeWidth="3" />
          <circle
            cx="18" cy="18" r={r} fill="none"
            stroke={color} strokeWidth="3"
            strokeDasharray={`${fill} ${circ}`}
            strokeLinecap="round"
          />
        </svg>
        <span className="absolute inset-0 flex items-center justify-center text-[10px] font-bold text-zinc-900">
          {score}
        </span>
      </div>
      <div>
        <span className="text-xs font-semibold" style={{ color }}>{label}</span>
      </div>
    </div>
  );
}

const aiExplanations: Record<string, { strengths: string[]; gaps: string[]; recommendation: string }> = {
  c1: {
    strengths: ['7+ years React experience at Stripe', 'Advanced TypeScript', 'Next.js production experience', 'Strong SaaS background'],
    gaps: ['Limited AWS hands-on experience'],
    recommendation: 'Highly recommended for technical interview. Exceptional React and TypeScript skills align perfectly with role requirements.',
  },
  c2: {
    strengths: ['10 years experience — exceeds requirement', 'Staff-level architecture skills', 'Deep Next.js expertise at Vercel', 'Open-source contributions'],
    gaps: ['Senior vs Staff level mismatch — may be overqualified', 'Higher salary expectation'],
    recommendation: 'Strong technical match. Discuss role scope and growth trajectory before proceeding.',
  },
  c3: {
    strengths: ['Design systems expertise', 'Accessibility champion (WCAG 2.2)', 'Strong TypeScript skills', 'Mentorship track record'],
    gaps: ['No backend API experience', 'Limited cloud infrastructure knowledge'],
    recommendation: 'Excellent culture fit for a team building high-quality UI systems. Recommend phone screen.',
  },
};

export default function CandidateRanking({ onNavigate, onSelectCandidate }: CandidateRankingProps) {
  const [search, setSearch] = useState('');
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [statusFilter, setStatusFilter] = useState<string>('all');

  const sorted = [...candidates].sort((a, b) => b.aiScore - a.aiScore);
  const filtered = sorted.filter(c => {
    const matchesSearch = c.name.toLowerCase().includes(search.toLowerCase()) ||
      c.skills.some(s => s.toLowerCase().includes(search.toLowerCase()));
    const matchesStatus = statusFilter === 'all' || c.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const selected = candidates.find(c => c.id === selectedId);
  const explanation = selectedId ? aiExplanations[selectedId] : null;

  const stats = [
    { label: 'Applicants', value: '128', color: 'text-zinc-800' },
    { label: 'Qualified', value: '42', color: 'text-sky-600' },
    { label: 'Strong Matches', value: '18', color: 'text-indigo-600' },
    { label: 'Top Candidates', value: '7', color: 'text-violet-600' },
  ];

  return (
    <div className="max-w-[1280px] mx-auto space-y-5 fade-in">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold text-zinc-900 tracking-tight">Senior Frontend Engineer</h1>
            <span className="px-2 py-0.5 bg-emerald-50 text-emerald-700 text-xs font-semibold rounded-md ring-1 ring-emerald-200">Hiring</span>
          </div>
          <div className="flex items-center gap-2 mt-1.5">
            <Sparkles size={13} className="text-violet-500" />
            <p className="text-sm text-zinc-500">
              <span className="font-semibold text-violet-600">128 candidates</span> analyzed by HireLens AI
            </p>
          </div>
        </div>
        <button
          onClick={() => onNavigate('comparison')}
          className="flex items-center gap-1.5 px-3 py-2 text-sm font-medium text-zinc-700 bg-white border border-zinc-200 rounded-lg hover:bg-zinc-50 transition-colors"
        >
          Compare Candidates <ChevronRight size={14} />
        </button>
      </div>

      {/* Stats */}
      <div className="flex items-center gap-6">
        {stats.map((s) => (
          <div key={s.label} className="flex items-center gap-2">
            <span className={`text-2xl font-bold font-mono ${s.color}`}>{s.value}</span>
            <span className="text-xs text-zinc-400">{s.label}</span>
          </div>
        ))}
      </div>

      <div className="flex gap-4">
        {/* Main table */}
        <div className="flex-1 min-w-0 space-y-3">
          {/* Toolbar */}
          <div className="flex items-center gap-2">
            <div className="flex-1 relative">
              <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-400" />
              <input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search candidates or skills..."
                className="w-full pl-9 pr-3 py-2 text-sm bg-white border border-zinc-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-200 transition-all"
              />
            </div>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="px-3 py-2 text-sm bg-white border border-zinc-200 rounded-lg text-zinc-600 focus:outline-none cursor-pointer"
            >
              <option value="all">All Status</option>
              <option value="new">New</option>
              <option value="shortlisted">Shortlisted</option>
              <option value="interview">Interview</option>
            </select>
            <button className="flex items-center gap-1.5 px-3 py-2 text-sm text-zinc-600 bg-white border border-zinc-200 rounded-lg hover:bg-zinc-50">
              <ArrowUpDown size={14} />
              Sort
            </button>
          </div>

          {/* Table */}
          <div className="bg-white border border-zinc-200 rounded-xl overflow-hidden">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-zinc-100 bg-zinc-50/50">
                  <th className="text-left px-4 py-3 text-xs font-semibold text-zinc-400 uppercase tracking-wide w-12">Rank</th>
                  <th className="text-left px-4 py-3 text-xs font-semibold text-zinc-400 uppercase tracking-wide">Candidate</th>
                  <th className="text-left px-4 py-3 text-xs font-semibold text-zinc-400 uppercase tracking-wide">AI Match</th>
                  <th className="text-left px-4 py-3 text-xs font-semibold text-zinc-400 uppercase tracking-wide">Exp.</th>
                  <th className="text-left px-4 py-3 text-xs font-semibold text-zinc-400 uppercase tracking-wide">Skills</th>
                  <th className="text-left px-4 py-3 text-xs font-semibold text-zinc-400 uppercase tracking-wide">Status</th>
                  <th className="px-4 py-3" />
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-50">
                {filtered.map((c, i) => {
                  const cfg = statusConfig[c.status];
                  const isSelected = selectedId === c.id;
                  return (
                    <tr
                      key={c.id}
                      onClick={() => setSelectedId(isSelected ? null : c.id)}
                      className={`cursor-pointer transition-colors group ${isSelected ? 'bg-indigo-50/60' : 'hover:bg-zinc-50/50'}`}
                    >
                      <td className="px-4 py-3.5">
                        <span className="text-xs font-mono font-bold text-zinc-400">
                          #{String(i + 1).padStart(2, '0')}
                        </span>
                      </td>
                      <td className="px-4 py-3.5">
                        <div className="flex items-center gap-2.5">
                          <div className={`size-8 rounded-full flex items-center justify-center text-xs font-bold flex-none ${c.color}`}>
                            {c.initials}
                          </div>
                          <div>
                            <p className="font-semibold text-zinc-900 text-sm">{c.name}</p>
                            <p className="text-[11px] text-zinc-400 mt-0.5">{c.currentRole} · {c.company}</p>
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-3.5">
                        <ScoreRing score={c.aiScore} />
                      </td>
                      <td className="px-4 py-3.5">
                        <span className="font-mono text-sm font-semibold text-zinc-800">{c.experienceYears}</span>
                        <span className="text-xs text-zinc-400"> yrs</span>
                      </td>
                      <td className="px-4 py-3.5">
                        <div className="flex items-center gap-1 flex-wrap">
                          {c.skills.slice(0, 3).map((s) => (
                            <span key={s} className="px-1.5 py-0.5 bg-zinc-100 text-zinc-600 text-[10px] font-medium rounded">
                              {s}
                            </span>
                          ))}
                          {c.skills.length > 3 && (
                            <span className="text-[10px] text-zinc-400">+{c.skills.length - 3}</span>
                          )}
                        </div>
                      </td>
                      <td className="px-4 py-3.5">
                        <span className={`inline-flex px-2 py-0.5 rounded-md text-[11px] font-semibold ${cfg.cls}`}>
                          {cfg.label}
                        </span>
                      </td>
                      <td className="px-4 py-3.5">
                        <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                          <button
                            onClick={(e) => { e.stopPropagation(); onSelectCandidate(c.id); onNavigate('profile'); }}
                            className="p-1.5 hover:bg-indigo-50 rounded-md text-zinc-400 hover:text-indigo-600 transition-colors"
                            title="View profile"
                          >
                            <Eye size={14} />
                          </button>
                          <button
                            onClick={(e) => e.stopPropagation()}
                            className="p-1.5 hover:bg-emerald-50 rounded-md text-zinc-400 hover:text-emerald-600 transition-colors"
                            title="Shortlist"
                          >
                            <Star size={14} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* AI Explanation Drawer */}
        {selected && explanation && (
          <div className="w-72 flex-none bg-white border border-zinc-200 rounded-xl p-4 space-y-4 fade-in self-start sticky top-0">
            <div className="flex items-start justify-between">
              <div>
                <div className="flex items-center gap-1.5 mb-1">
                  <Sparkles size={13} className="text-violet-500" />
                  <span className="text-[10px] font-semibold text-violet-500 uppercase tracking-wide">AI Analysis</span>
                </div>
                <p className="text-sm font-semibold text-zinc-900">Why {selected.name.split(' ')[0]} is a {selected.aiScore}% match</p>
              </div>
              <button onClick={() => setSelectedId(null)} className="p-1 hover:bg-zinc-100 rounded text-zinc-400">
                <X size={14} />
              </button>
            </div>

            <div>
              <p className="text-[10px] font-semibold uppercase tracking-wide text-zinc-400 mb-2">Strong Matches</p>
              <div className="space-y-1.5">
                {explanation.strengths.map((s) => (
                  <div key={s} className="flex items-start gap-2">
                    <Check size={12} className="text-emerald-500 mt-0.5 flex-none" />
                    <span className="text-xs text-zinc-600">{s}</span>
                  </div>
                ))}
              </div>
            </div>

            {explanation.gaps.length > 0 && (
              <div>
                <p className="text-[10px] font-semibold uppercase tracking-wide text-zinc-400 mb-2">Potential Gaps</p>
                <div className="space-y-1.5">
                  {explanation.gaps.map((g) => (
                    <div key={g} className="flex items-start gap-2">
                      <AlertTriangle size={12} className="text-amber-500 mt-0.5 flex-none" />
                      <span className="text-xs text-zinc-600">{g}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            <div className="p-3 bg-indigo-50 rounded-lg">
              <p className="text-[10px] font-semibold text-indigo-600 uppercase tracking-wide mb-1">AI Recommendation</p>
              <p className="text-xs text-indigo-800 leading-relaxed">{explanation.recommendation}</p>
            </div>

            <button
              onClick={() => { onSelectCandidate(selected.id); onNavigate('profile'); }}
              className="w-full flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-semibold text-white bg-indigo-600 rounded-lg hover:bg-indigo-700 transition-colors"
            >
              Full Profile <ArrowRight size={12} />
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
