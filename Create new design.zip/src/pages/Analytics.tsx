import { useState } from 'react';
import {
  AreaChart, Area, BarChart, Bar, LineChart, Line,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
} from 'recharts';
import { Download, TrendingDown, TrendingUp, Clock, DollarSign, Users, Target, Filter } from 'lucide-react';
import { analyticsData } from '../data/mock';

const kpis = [
  { label: 'Avg Time to Hire', value: '18 days', delta: '-3 days', up: true, icon: Clock, color: 'text-sky-600', bg: 'bg-sky-50' },
  { label: 'Cost per Hire', value: '$4,820', delta: '-8.2%', up: true, icon: DollarSign, color: 'text-emerald-600', bg: 'bg-emerald-50' },
  { label: 'Offer Acceptance', value: '82%', delta: '+4%', up: true, icon: Target, color: 'text-indigo-600', bg: 'bg-indigo-50' },
  { label: 'Total Hired', value: '47', delta: '+12 YTD', up: true, icon: Users, color: 'text-violet-600', bg: 'bg-violet-50' },
];

const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload?.length) {
    return (
      <div className="bg-white border border-zinc-200 rounded-lg px-3 py-2 shadow-sm text-xs">
        <p className="font-semibold text-zinc-700 mb-1">{label}</p>
        {payload.map((p: any) => (
          <p key={p.dataKey} style={{ color: p.color }}>
            {p.name}: <span className="font-mono font-semibold">{p.value}{p.unit ?? ''}</span>
          </p>
        ))}
      </div>
    );
  }
  return null;
};

export default function Analytics() {
  const [dateRange, setDateRange] = useState('6M');

  return (
    <div className="max-w-[1280px] mx-auto space-y-5 fade-in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-zinc-900 tracking-tight">Analytics</h1>
          <p className="text-sm text-zinc-500 mt-0.5">Recruitment performance · all jobs</p>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1 bg-zinc-100 rounded-lg p-1">
            {['1M', '3M', '6M', '1Y'].map((r) => (
              <button
                key={r}
                onClick={() => setDateRange(r)}
                className={`px-2.5 py-1 text-xs font-medium rounded-md transition-all ${
                  dateRange === r ? 'bg-white text-zinc-900 shadow-sm' : 'text-zinc-500 hover:text-zinc-700'
                }`}
              >
                {r}
              </button>
            ))}
          </div>
          <button className="flex items-center gap-1.5 px-3 py-2 text-sm text-zinc-600 bg-white border border-zinc-200 rounded-lg hover:bg-zinc-50 transition-colors">
            <Filter size={14} />
            Filter
          </button>
          <button className="flex items-center gap-1.5 px-3 py-2 text-sm font-medium text-zinc-700 bg-white border border-zinc-200 rounded-lg hover:bg-zinc-50 transition-colors">
            <Download size={14} />
            Export Report
          </button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-4 gap-3">
        {kpis.map((kpi) => {
          const Icon = kpi.icon;
          return (
            <div key={kpi.label} className="bg-white border border-zinc-200 rounded-xl p-4">
              <div className="flex items-center justify-between mb-3">
                <div className={`size-8 rounded-lg ${kpi.bg} flex items-center justify-center`}>
                  <Icon size={15} className={kpi.color} />
                </div>
                {kpi.up
                  ? <TrendingUp size={14} className="text-emerald-500" />
                  : <TrendingDown size={14} className="text-red-500" />}
              </div>
              <p className="text-2xl font-bold text-zinc-900 font-mono">{kpi.value}</p>
              <p className="text-xs text-zinc-500 mt-0.5">{kpi.label}</p>
              <p className={`text-xs font-semibold mt-1.5 ${kpi.up ? 'text-emerald-600' : 'text-red-500'}`}>
                {kpi.delta} vs last period
              </p>
            </div>
          );
        })}
      </div>

      {/* Charts Row 1 */}
      <div className="grid grid-cols-2 gap-4">
        {/* Time to Hire */}
        <div className="bg-white border border-zinc-200 rounded-xl p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-semibold text-zinc-900">Time to Hire</h3>
              <p className="text-xs text-zinc-500 mt-0.5">Average days per hire · 6 months</p>
            </div>
            <span className="text-xs font-mono font-bold text-sky-600 bg-sky-50 px-2 py-1 rounded-lg">↓ 25%</span>
          </div>
          <ResponsiveContainer width="100%" height={180}>
            <AreaChart data={analyticsData.timeToHire} margin={{ top: 0, right: 0, bottom: 0, left: -20 }}>
              <defs>
                <linearGradient id="areaGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#0ea5e9" stopOpacity={0.1} />
                  <stop offset="95%" stopColor="#0ea5e9" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#f4f4f5" />
              <XAxis dataKey="month" tick={{ fontSize: 11, fill: '#a1a1aa' }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 11, fill: '#a1a1aa' }} axisLine={false} tickLine={false} />
              <Tooltip content={<CustomTooltip />} />
              <Area type="monotone" dataKey="days" name="Days" stroke="#0ea5e9" strokeWidth={2} fill="url(#areaGrad)" dot={{ r: 3, fill: '#0ea5e9', strokeWidth: 0 }} />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Offer Acceptance */}
        <div className="bg-white border border-zinc-200 rounded-xl p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-semibold text-zinc-900">Offer Acceptance Rate</h3>
              <p className="text-xs text-zinc-500 mt-0.5">Monthly % · 6 months</p>
            </div>
            <span className="text-xs font-mono font-bold text-emerald-600 bg-emerald-50 px-2 py-1 rounded-lg">↑ 14%</span>
          </div>
          <ResponsiveContainer width="100%" height={180}>
            <LineChart data={analyticsData.offerAcceptance} margin={{ top: 0, right: 0, bottom: 0, left: -20 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f4f4f5" />
              <XAxis dataKey="month" tick={{ fontSize: 11, fill: '#a1a1aa' }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 11, fill: '#a1a1aa' }} axisLine={false} tickLine={false} domain={[60, 90]} />
              <Tooltip content={<CustomTooltip />} />
              <Line type="monotone" dataKey="rate" name="Rate" stroke="#10b981" strokeWidth={2} unit="%" dot={{ r: 3, fill: '#10b981', strokeWidth: 0 }} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Charts Row 2 */}
      <div className="grid grid-cols-3 gap-4">
        {/* Source Performance */}
        <div className="col-span-2 bg-white border border-zinc-200 rounded-xl p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-semibold text-zinc-900">Source Performance</h3>
              <p className="text-xs text-zinc-500 mt-0.5">Candidates by source · qualification rate</p>
            </div>
          </div>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={analyticsData.sourcePerformance} margin={{ top: 0, right: 0, bottom: 0, left: -20 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f4f4f5" vertical={false} />
              <XAxis dataKey="source" tick={{ fontSize: 11, fill: '#a1a1aa' }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 11, fill: '#a1a1aa' }} axisLine={false} tickLine={false} />
              <Tooltip content={<CustomTooltip />} />
              <Bar dataKey="candidates" name="Total" fill="#e0e7ff" radius={[3, 3, 0, 0]} />
              <Bar dataKey="qualified" name="Qualified" fill="#4f46e5" radius={[3, 3, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Recruiter Performance */}
        <div className="bg-white border border-zinc-200 rounded-xl p-5">
          <h3 className="text-sm font-semibold text-zinc-900 mb-4">Recruiter Performance</h3>
          <div className="space-y-4">
            {analyticsData.recruiterPerformance.map((r, i) => (
              <div key={r.name}>
                <div className="flex items-center justify-between mb-1">
                  <div className="flex items-center gap-2">
                    <div className="size-6 rounded-full bg-gradient-to-br from-indigo-300 to-violet-400 flex items-center justify-center text-[10px] font-bold text-white">
                      {r.name.split(' ').map(n => n[0]).join('')}
                    </div>
                    <span className="text-xs font-medium text-zinc-700">{r.name.split(' ')[0]}</span>
                  </div>
                  <span className="text-xs font-mono font-bold text-zinc-900">{r.closed}</span>
                </div>
                <div className="h-1.5 bg-zinc-100 rounded-full overflow-hidden">
                  <div
                    className="h-full rounded-full"
                    style={{
                      width: `${(r.closed / 14) * 100}%`,
                      background: `hsl(${240 - i * 30}, 70%, 60%)`,
                    }}
                  />
                </div>
                <p className="text-[10px] text-zinc-400 mt-1">{r.closed} hires · {r.avgTime} day avg</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
