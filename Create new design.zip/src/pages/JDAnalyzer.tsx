import { useState } from 'react';
import { Sparkles, CheckCircle, AlertTriangle, XCircle, Lightbulb, RefreshCw, Copy, ChevronDown } from 'lucide-react';

const defaultJD = `Senior Frontend Engineer

We are looking for a Senior Frontend Engineer to join our growing engineering team. You will work closely with design and product teams to build exceptional user experiences.

Responsibilities:
- Build and maintain high-quality React applications
- Collaborate with designers to implement pixel-perfect UIs
- Write clean, maintainable TypeScript code
- Participate in code reviews and technical discussions
- Mentor junior engineers

Requirements:
- 5+ years of frontend engineering experience
- Strong proficiency in React and TypeScript
- Experience with Next.js and modern build tools
- Understanding of web performance and accessibility
- Excellent communication skills

Nice to have:
- Experience with GraphQL
- Familiarity with design systems
- Open source contributions`;

const analysis = {
  score: 92,
  requiredSkills: ['React', 'TypeScript', 'JavaScript', 'Next.js', 'Build Tools', 'Performance', 'Accessibility'],
  preferredSkills: ['GraphQL', 'Design Systems', 'Open Source'],
  experience: '5+ years',
  education: 'Not specified',
  issues: [
    { type: 'warning', text: 'Salary range not mentioned — top candidates typically expect this upfront.' },
    { type: 'warning', text: 'Remote/office arrangement not specified.' },
    { type: 'info', text: 'Consider specifying expected experience with React Server Components.' },
    { type: 'success', text: 'Clear responsibilities section reduces misaligned applications.' },
    { type: 'success', text: 'Mentorship requirement attracts senior candidates.' },
  ],
  suggestions: [
    'Add a salary range ($140k–$180k) to increase quality applications by ~40%',
    'Specify work arrangement (Remote / Hybrid / On-site)',
    'Add React Server Components as a preferred skill',
    'Mention team size and engineering culture',
    'Include growth opportunities to attract senior talent',
  ],
};

function ScoreDonut({ score }: { score: number }) {
  const r = 30;
  const circ = 2 * Math.PI * r;
  const fill = (score / 100) * circ;
  const color = score >= 90 ? '#10b981' : score >= 70 ? '#f59e0b' : '#ef4444';

  return (
    <div className="flex items-center gap-3">
      <div className="relative size-16">
        <svg viewBox="0 0 68 68" className="size-16 -rotate-90">
          <circle cx="34" cy="34" r={r} fill="none" stroke="#f4f4f5" strokeWidth="5" />
          <circle cx="34" cy="34" r={r} fill="none" stroke={color} strokeWidth="5"
            strokeDasharray={`${fill} ${circ}`} strokeLinecap="round" />
        </svg>
        <span className="absolute inset-0 flex items-center justify-center text-lg font-bold text-zinc-900">{score}</span>
      </div>
      <div>
        <p className="text-sm font-bold text-zinc-900">JD Quality Score</p>
        <p className="text-xs text-zinc-500 mt-0.5">
          {score >= 90 ? 'Excellent — ready to publish' : score >= 70 ? 'Good — minor improvements suggested' : 'Needs improvement'}
        </p>
        <p className="text-xs text-emerald-600 font-medium mt-1">out of 100</p>
      </div>
    </div>
  );
}

export default function JDAnalyzer() {
  const [jdText, setJdText] = useState(defaultJD);
  const [analyzing, setAnalyzing] = useState(false);
  const [analyzed, setAnalyzed] = useState(true);

  const runAnalysis = () => {
    setAnalyzing(true);
    setAnalyzed(false);
    setTimeout(() => {
      setAnalyzing(false);
      setAnalyzed(true);
    }, 1800);
  };

  return (
    <div className="max-w-[1280px] mx-auto space-y-5 fade-in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-zinc-900 tracking-tight">JD Analyzer</h1>
          <p className="text-sm text-zinc-500 mt-0.5">AI-powered job description analysis and optimization</p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => navigator.clipboard?.writeText(jdText)}
            className="flex items-center gap-1.5 px-3 py-2 text-sm text-zinc-600 bg-white border border-zinc-200 rounded-lg hover:bg-zinc-50 transition-colors"
          >
            <Copy size={14} />
            Copy JD
          </button>
          <button
            onClick={runAnalysis}
            className="flex items-center gap-1.5 px-3 py-2 text-sm font-semibold text-white bg-indigo-600 rounded-lg hover:bg-indigo-700 transition-colors"
          >
            <Sparkles size={14} />
            {analyzing ? 'Analyzing...' : 'Analyze JD'}
          </button>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4 h-[calc(100vh-220px)]">
        {/* Editor */}
        <div className="bg-white border border-zinc-200 rounded-xl flex flex-col overflow-hidden">
          <div className="flex items-center justify-between px-4 py-3 border-b border-zinc-100">
            <span className="text-xs font-semibold text-zinc-600">Job Description</span>
            <div className="flex items-center gap-2">
              <span className="text-[10px] text-zinc-400 font-mono">{jdText.split(/\s+/).length} words</span>
              <button
                onClick={() => setJdText(defaultJD)}
                className="p-1 hover:bg-zinc-100 rounded text-zinc-400 hover:text-zinc-600"
              >
                <RefreshCw size={12} />
              </button>
            </div>
          </div>
          <textarea
            value={jdText}
            onChange={(e) => setJdText(e.target.value)}
            className="flex-1 p-4 text-sm text-zinc-700 leading-relaxed resize-none focus:outline-none font-mono"
            spellCheck={false}
          />
          <div className="px-4 py-2.5 border-t border-zinc-100 flex items-center justify-between">
            <button className="flex items-center gap-1.5 text-xs text-violet-600 hover:text-violet-700 font-medium transition-colors">
              <Sparkles size={12} />
              Generate with AI
            </button>
            <span className="text-[10px] text-zinc-400">Last analyzed · just now</span>
          </div>
        </div>

        {/* Analysis Panel */}
        <div className="bg-white border border-zinc-200 rounded-xl flex flex-col overflow-hidden">
          <div className="flex items-center gap-2 px-4 py-3 border-b border-zinc-100">
            <div className="size-5 rounded bg-violet-100 flex items-center justify-center">
              <Sparkles size={11} className="text-violet-600" />
            </div>
            <span className="text-xs font-semibold text-zinc-700">AI Analysis</span>
            {analyzing && (
              <div className="flex items-center gap-1.5 ml-2">
                <div className="size-1.5 rounded-full bg-violet-400 animate-pulse" />
                <span className="text-[10px] text-violet-500">Analyzing...</span>
              </div>
            )}
          </div>

          <div className="flex-1 overflow-y-auto p-4 space-y-5">
            {analyzing ? (
              <div className="space-y-3">
                {[80, 60, 90, 50, 70].map((w, i) => (
                  <div key={i} className="skeleton h-4 rounded" style={{ width: `${w}%` }} />
                ))}
              </div>
            ) : analyzed ? (
              <>
                {/* Score */}
                <ScoreDonut score={analysis.score} />

                {/* Skills */}
                <div>
                  <p className="text-[10px] font-semibold uppercase tracking-widest text-zinc-400 mb-2">Required Skills</p>
                  <div className="flex flex-wrap gap-1.5">
                    {analysis.requiredSkills.map((s) => (
                      <span key={s} className="px-2 py-0.5 bg-indigo-50 text-indigo-700 text-[11px] font-medium rounded-md">
                        {s}
                      </span>
                    ))}
                  </div>
                </div>

                <div>
                  <p className="text-[10px] font-semibold uppercase tracking-widest text-zinc-400 mb-2">Preferred Skills</p>
                  <div className="flex flex-wrap gap-1.5">
                    {analysis.preferredSkills.map((s) => (
                      <span key={s} className="px-2 py-0.5 bg-zinc-100 text-zinc-600 text-[11px] font-medium rounded-md">
                        {s}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Issues */}
                <div>
                  <p className="text-[10px] font-semibold uppercase tracking-widest text-zinc-400 mb-2">Analysis</p>
                  <div className="space-y-2">
                    {analysis.issues.map((issue, i) => {
                      const Icon = issue.type === 'success' ? CheckCircle : issue.type === 'warning' ? AlertTriangle : XCircle;
                      const cls = issue.type === 'success' ? 'text-emerald-500' : issue.type === 'warning' ? 'text-amber-500' : 'text-zinc-400';
                      const bgCls = issue.type === 'success' ? 'bg-emerald-50' : issue.type === 'warning' ? 'bg-amber-50' : 'bg-zinc-50';
                      return (
                        <div key={i} className={`flex items-start gap-2 p-2.5 rounded-lg ${bgCls}`}>
                          <Icon size={13} className={`flex-none mt-0.5 ${cls}`} />
                          <span className="text-xs text-zinc-600 leading-relaxed">{issue.text}</span>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Suggestions */}
                <div>
                  <p className="text-[10px] font-semibold uppercase tracking-widest text-zinc-400 mb-2">AI Suggestions</p>
                  <div className="space-y-2">
                    {analysis.suggestions.map((s, i) => (
                      <div key={i} className="flex items-start gap-2">
                        <Lightbulb size={12} className="text-violet-400 flex-none mt-0.5" />
                        <span className="text-xs text-zinc-600 leading-relaxed">{s}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </>
            ) : (
              <div className="flex flex-col items-center justify-center h-48 text-center">
                <p className="text-sm text-zinc-500">Paste a job description and click Analyze JD</p>
              </div>
            )}
          </div>

          {analyzed && !analyzing && (
            <div className="border-t border-zinc-100 p-3">
              <button className="w-full flex items-center justify-center gap-1.5 px-3 py-2.5 text-xs font-semibold text-white bg-indigo-600 rounded-lg hover:bg-indigo-700 transition-colors">
                <Sparkles size={13} />
                Improve Job Description with AI
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
