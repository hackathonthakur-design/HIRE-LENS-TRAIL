import { useState } from 'react';
import { Check, ChevronRight, Sparkles, Plus, X, ArrowLeft, ArrowRight } from 'lucide-react';
import type { Page } from '../types';

interface CreateJobProps {
  onNavigate: (page: Page) => void;
}

const steps = [
  { num: '01', label: 'Basics' },
  { num: '02', label: 'Description' },
  { num: '03', label: 'Requirements' },
  { num: '04', label: 'Screening' },
  { num: '05', label: 'Review' },
];

const departments = ['Engineering', 'Design', 'Product', 'Data', 'Marketing', 'Sales', 'Operations', 'Finance'];
const locations = ['Remote', 'San Francisco, CA', 'New York, NY', 'Austin, TX', 'Seattle, WA', 'Chicago, IL'];
const employmentTypes = ['Full-time', 'Part-time', 'Contract', 'Internship'];
const experienceLevels = ['Entry Level', 'Mid Level', 'Senior Level', 'Staff / Principal', 'Manager'];

const skillOptions = ['React', 'TypeScript', 'Next.js', 'Node.js', 'GraphQL', 'AWS', 'Python', 'Go', 'PostgreSQL', 'Redis', 'Docker', 'Kubernetes', 'Figma', 'CSS'];

export default function CreateJob({ onNavigate }: CreateJobProps) {
  const [step, setStep] = useState(0);
  const [skills, setSkills] = useState<string[]>(['React', 'TypeScript', 'Next.js']);
  const [preferredSkills, setPreferredSkills] = useState<string[]>(['GraphQL', 'AWS']);
  const [aiPrompt, setAiPrompt] = useState('');
  const [generating, setGenerating] = useState(false);
  const [form, setForm] = useState({
    title: 'Senior Frontend Engineer',
    department: 'Engineering',
    location: 'Remote',
    type: 'Full-time',
    salaryMin: '160',
    salaryMax: '200',
    experience: 'Senior Level',
    description: '',
    responsibilities: '',
  });

  const set = (key: string, value: string) => setForm(prev => ({ ...prev, [key]: value }));

  const generateWithAI = () => {
    setGenerating(true);
    setTimeout(() => {
      set('description', `We are looking for a ${form.title} to join our ${form.department} team. You will be responsible for building and maintaining high-quality, performant web applications that delight our users.\n\nYou will collaborate closely with design, product, and backend teams to ship features that are used by thousands of customers every day.`);
      set('responsibilities', `• Design and implement scalable frontend architectures using React and TypeScript\n• Build reusable component libraries and maintain design system alignment\n• Lead technical discussions and code reviews\n• Optimize application performance and core web vitals\n• Mentor junior engineers and contribute to engineering culture`);
      setGenerating(false);
    }, 1500);
  };

  const toggleSkill = (skill: string, list: string[], setter: (v: string[]) => void) => {
    setter(list.includes(skill) ? list.filter(s => s !== skill) : [...list, skill]);
  };

  return (
    <div className="max-w-[800px] mx-auto space-y-6 fade-in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <button
          onClick={() => onNavigate('jobs')}
          className="flex items-center gap-1.5 text-sm text-zinc-500 hover:text-zinc-800 transition-colors"
        >
          <ArrowLeft size={14} />
          Back to Jobs
        </button>
        <h1 className="text-lg font-bold text-zinc-900">Create Job</h1>
        <div className="w-20" />
      </div>

      {/* Step indicator */}
      <div className="flex items-center gap-0">
        {steps.map((s, i) => {
          const done = i < step;
          const active = i === step;
          return (
            <div key={s.num} className="flex items-center flex-1">
              <button
                onClick={() => i <= step && setStep(i)}
                className="flex items-center gap-2 flex-none"
              >
                <div className={`size-8 rounded-full flex items-center justify-center text-xs font-bold transition-all ${
                  done ? 'bg-indigo-600 text-white' : active ? 'bg-indigo-600 text-white ring-4 ring-indigo-100' : 'bg-zinc-100 text-zinc-400'
                }`}>
                  {done ? <Check size={14} /> : s.num}
                </div>
                <span className={`text-xs font-medium ${active ? 'text-zinc-900' : done ? 'text-zinc-500' : 'text-zinc-400'}`}>
                  {s.label}
                </span>
              </button>
              {i < steps.length - 1 && (
                <div className={`flex-1 h-px mx-3 ${i < step ? 'bg-indigo-300' : 'bg-zinc-200'}`} />
              )}
            </div>
          );
        })}
      </div>

      {/* Step Content */}
      <div className="bg-white border border-zinc-200 rounded-xl p-6 space-y-5">
        {step === 0 && (
          <>
            <h2 className="text-base font-semibold text-zinc-900">Basic Information</h2>
            <div className="grid grid-cols-2 gap-4">
              <div className="col-span-2">
                <label className="block text-xs font-medium text-zinc-600 mb-1.5">Job Title</label>
                <input
                  value={form.title}
                  onChange={(e) => set('title', e.target.value)}
                  placeholder="e.g. Senior Frontend Engineer"
                  className="w-full px-3 py-2 text-sm border border-zinc-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-200 focus:border-indigo-400 transition-all"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-zinc-600 mb-1.5">Department</label>
                <select
                  value={form.department}
                  onChange={(e) => set('department', e.target.value)}
                  className="w-full px-3 py-2 text-sm border border-zinc-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-200 bg-white"
                >
                  {departments.map(d => <option key={d}>{d}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium text-zinc-600 mb-1.5">Location</label>
                <select
                  value={form.location}
                  onChange={(e) => set('location', e.target.value)}
                  className="w-full px-3 py-2 text-sm border border-zinc-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-200 bg-white"
                >
                  {locations.map(l => <option key={l}>{l}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium text-zinc-600 mb-1.5">Employment Type</label>
                <select
                  value={form.type}
                  onChange={(e) => set('type', e.target.value)}
                  className="w-full px-3 py-2 text-sm border border-zinc-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-200 bg-white"
                >
                  {employmentTypes.map(t => <option key={t}>{t}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium text-zinc-600 mb-1.5">Experience Level</label>
                <select
                  value={form.experience}
                  onChange={(e) => set('experience', e.target.value)}
                  className="w-full px-3 py-2 text-sm border border-zinc-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-200 bg-white"
                >
                  {experienceLevels.map(e => <option key={e}>{e}</option>)}
                </select>
              </div>
              <div className="col-span-2">
                <label className="block text-xs font-medium text-zinc-600 mb-1.5">Salary Range (USD, thousands)</label>
                <div className="flex items-center gap-2">
                  <span className="text-sm text-zinc-500">$</span>
                  <input
                    value={form.salaryMin}
                    onChange={(e) => set('salaryMin', e.target.value)}
                    placeholder="160"
                    className="w-24 px-3 py-2 text-sm border border-zinc-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-200"
                  />
                  <span className="text-sm text-zinc-400">k — $</span>
                  <input
                    value={form.salaryMax}
                    onChange={(e) => set('salaryMax', e.target.value)}
                    placeholder="200"
                    className="w-24 px-3 py-2 text-sm border border-zinc-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-200"
                  />
                  <span className="text-sm text-zinc-400">k / year</span>
                </div>
              </div>
            </div>
          </>
        )}

        {step === 1 && (
          <>
            <div className="flex items-center justify-between">
              <h2 className="text-base font-semibold text-zinc-900">Job Description</h2>
              <div className="flex items-center gap-2">
                <input
                  value={aiPrompt}
                  onChange={(e) => setAiPrompt(e.target.value)}
                  placeholder="e.g. Senior React dev for fintech startup..."
                  className="px-3 py-1.5 text-xs border border-zinc-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-200 w-56"
                />
                <button
                  onClick={generateWithAI}
                  disabled={generating}
                  className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-violet-700 bg-violet-50 hover:bg-violet-100 rounded-lg transition-colors disabled:opacity-50"
                >
                  <Sparkles size={12} />
                  {generating ? 'Generating...' : 'Generate with AI'}
                </button>
              </div>
            </div>
            <div>
              <label className="block text-xs font-medium text-zinc-600 mb-1.5">Description</label>
              <textarea
                value={form.description}
                onChange={(e) => set('description', e.target.value)}
                placeholder="Describe the role and what the candidate will work on..."
                rows={5}
                className="w-full px-3 py-2 text-sm border border-zinc-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-200 resize-none leading-relaxed"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-zinc-600 mb-1.5">Responsibilities</label>
              <textarea
                value={form.responsibilities}
                onChange={(e) => set('responsibilities', e.target.value)}
                placeholder="List key responsibilities..."
                rows={6}
                className="w-full px-3 py-2 text-sm border border-zinc-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-200 resize-none leading-relaxed font-mono"
              />
            </div>
          </>
        )}

        {step === 2 && (
          <>
            <h2 className="text-base font-semibold text-zinc-900">Requirements</h2>
            <div>
              <label className="block text-xs font-medium text-zinc-600 mb-2">Required Skills</label>
              <div className="flex flex-wrap gap-2 mb-2">
                {skills.map(s => (
                  <button
                    key={s}
                    onClick={() => toggleSkill(s, skills, setSkills)}
                    className="flex items-center gap-1.5 px-2.5 py-1 bg-indigo-50 text-indigo-700 text-xs font-medium rounded-md hover:bg-indigo-100 transition-colors"
                  >
                    {s} <X size={10} />
                  </button>
                ))}
              </div>
              <div className="flex flex-wrap gap-1.5 p-3 bg-zinc-50 rounded-lg">
                {skillOptions.filter(s => !skills.includes(s)).map(s => (
                  <button
                    key={s}
                    onClick={() => toggleSkill(s, skills, setSkills)}
                    className="flex items-center gap-1 px-2 py-0.5 bg-white text-zinc-600 text-xs font-medium rounded border border-zinc-200 hover:border-indigo-300 hover:text-indigo-600 transition-colors"
                  >
                    <Plus size={9} /> {s}
                  </button>
                ))}
              </div>
            </div>
            <div>
              <label className="block text-xs font-medium text-zinc-600 mb-2">Preferred Skills</label>
              <div className="flex flex-wrap gap-2 mb-2">
                {preferredSkills.map(s => (
                  <button
                    key={s}
                    onClick={() => toggleSkill(s, preferredSkills, setPreferredSkills)}
                    className="flex items-center gap-1.5 px-2.5 py-1 bg-zinc-100 text-zinc-600 text-xs font-medium rounded-md hover:bg-zinc-200 transition-colors"
                  >
                    {s} <X size={10} />
                  </button>
                ))}
              </div>
              <div className="flex flex-wrap gap-1.5 p-3 bg-zinc-50 rounded-lg">
                {skillOptions.filter(s => !preferredSkills.includes(s) && !skills.includes(s)).map(s => (
                  <button
                    key={s}
                    onClick={() => toggleSkill(s, preferredSkills, setPreferredSkills)}
                    className="flex items-center gap-1 px-2 py-0.5 bg-white text-zinc-600 text-xs font-medium rounded border border-zinc-200 hover:border-zinc-400 transition-colors"
                  >
                    <Plus size={9} /> {s}
                  </button>
                ))}
              </div>
            </div>
          </>
        )}

        {step === 3 && (
          <>
            <h2 className="text-base font-semibold text-zinc-900">AI Screening Setup</h2>
            <div className="space-y-3">
              {[
                { label: 'AI Resume Screening', desc: 'Automatically screen and rank all incoming resumes', enabled: true },
                { label: 'Bias Detection', desc: 'Flag potential bias indicators in screening process', enabled: true },
                { label: 'Skills Assessment', desc: 'Send automated technical assessment to qualified candidates', enabled: false },
                { label: 'Automated Outreach', desc: 'Send personalized emails to strong matches', enabled: false },
              ].map((item) => (
                <div key={item.label} className="flex items-start justify-between p-3.5 border border-zinc-200 rounded-lg">
                  <div>
                    <p className="text-sm font-medium text-zinc-800">{item.label}</p>
                    <p className="text-xs text-zinc-500 mt-0.5">{item.desc}</p>
                  </div>
                  <div className={`flex-none mt-0.5 w-9 h-5 rounded-full transition-colors cursor-pointer ${item.enabled ? 'bg-indigo-600' : 'bg-zinc-200'}`}>
                    <div className={`size-4 bg-white rounded-full shadow-sm mt-0.5 transition-all ${item.enabled ? 'ml-4' : 'ml-0.5'}`} />
                  </div>
                </div>
              ))}
            </div>
            <div className="p-3.5 bg-violet-50 border border-violet-100 rounded-lg flex items-start gap-2.5">
              <Sparkles size={14} className="text-violet-500 flex-none mt-0.5" />
              <div>
                <p className="text-xs font-semibold text-violet-700">AI will analyze {skills.length} required and {preferredSkills.length} preferred skills</p>
                <p className="text-xs text-violet-600 mt-0.5">Candidates will be ranked from 0–100% based on match with your requirements.</p>
              </div>
            </div>
          </>
        )}

        {step === 4 && (
          <>
            <h2 className="text-base font-semibold text-zinc-900">Review & Publish</h2>
            <div className="divide-y divide-zinc-100">
              {[
                { label: 'Job Title', value: form.title },
                { label: 'Department', value: form.department },
                { label: 'Location', value: form.location },
                { label: 'Type', value: form.type },
                { label: 'Experience', value: form.experience },
                { label: 'Salary Range', value: `$${form.salaryMin}k – $${form.salaryMax}k` },
                { label: 'Required Skills', value: skills.join(', ') },
                { label: 'Preferred Skills', value: preferredSkills.join(', ') },
              ].map(({ label, value }) => (
                <div key={label} className="flex items-baseline gap-4 py-2.5">
                  <span className="text-xs font-medium text-zinc-400 w-32 flex-none">{label}</span>
                  <span className="text-sm text-zinc-800">{value || '—'}</span>
                </div>
              ))}
            </div>
            <div className="flex items-center gap-2 pt-2">
              <button
                onClick={() => onNavigate('jobs')}
                className="flex-1 py-2.5 text-sm font-semibold text-zinc-700 bg-white border border-zinc-200 rounded-lg hover:bg-zinc-50 transition-colors"
              >
                Save as Draft
              </button>
              <button
                onClick={() => onNavigate('jobs')}
                className="flex-1 py-2.5 text-sm font-semibold text-white bg-indigo-600 rounded-lg hover:bg-indigo-700 transition-colors"
              >
                Publish Job
              </button>
            </div>
          </>
        )}
      </div>

      {/* Navigation */}
      {step < 4 && (
        <div className="flex items-center justify-between">
          <button
            onClick={() => setStep(Math.max(0, step - 1))}
            disabled={step === 0}
            className="flex items-center gap-1.5 px-4 py-2 text-sm font-medium text-zinc-600 bg-white border border-zinc-200 rounded-lg hover:bg-zinc-50 transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
          >
            <ArrowLeft size={14} />
            Previous
          </button>
          <button
            onClick={() => setStep(Math.min(4, step + 1))}
            className="flex items-center gap-1.5 px-4 py-2 text-sm font-semibold text-white bg-indigo-600 rounded-lg hover:bg-indigo-700 transition-colors"
          >
            Continue <ArrowRight size={14} />
          </button>
        </div>
      )}
    </div>
  );
}
