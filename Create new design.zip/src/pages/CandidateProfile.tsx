import { useState } from 'react';
import {
  Mail, Phone, Link, MapPin, Star, X, Calendar,
  Sparkles, Check, AlertTriangle, MessageSquare, ChevronRight,
  Briefcase, GraduationCap, Award, ArrowLeft,
} from 'lucide-react';
import { candidates } from '../data/mock';
import type { Page } from '../types';

interface CandidateProfileProps {
  candidateId: string;
  onNavigate: (page: Page) => void;
}

const tabs = ['Overview', 'AI Analysis', 'Experience', 'Skills', 'Education', 'Interviews', 'Activity'];

function ScoreRing({ score, size = 'lg' }: { score: number; size?: 'sm' | 'lg' }) {
  const r = size === 'lg' ? 28 : 16;
  const sw = size === 'lg' ? 4 : 3;
  const vb = size === 'lg' ? '0 0 64 64' : '0 0 36 36';
  const cx = size === 'lg' ? 32 : 18;
  const dim = size === 'lg' ? 'size-16' : 'size-9';
  const textCls = size === 'lg' ? 'text-lg font-bold' : 'text-[10px] font-bold';
  const circ = 2 * Math.PI * r;
  const fill = (score / 100) * circ;
  const color = score >= 90 ? '#4f46e5' : score >= 80 ? '#7c3aed' : score >= 70 ? '#0ea5e9' : '#f59e0b';

  return (
    <div className={`relative flex-none ${dim}`}>
      <svg viewBox={vb} className={`${dim} -rotate-90`}>
        <circle cx={cx} cy={cx} r={r} fill="none" stroke="#f4f4f5" strokeWidth={sw} />
        <circle cx={cx} cy={cx} r={r} fill="none" stroke={color} strokeWidth={sw}
          strokeDasharray={`${fill} ${circ}`} strokeLinecap="round" />
      </svg>
      <span className={`absolute inset-0 flex items-center justify-center ${textCls} text-zinc-900`}>{score}</span>
    </div>
  );
}

function ProgressBar({ value, color = '#4f46e5' }: { value: number; color?: string }) {
  return (
    <div className="flex items-center gap-3">
      <div className="flex-1 h-1.5 bg-zinc-100 rounded-full overflow-hidden">
        <div className="h-full rounded-full transition-all duration-700" style={{ width: `${value}%`, backgroundColor: color }} />
      </div>
      <span className="text-xs font-mono font-semibold text-zinc-700 w-8 text-right">{value}%</span>
    </div>
  );
}

const interviewQuestions = [
  'Describe your approach to React Server Components and when you prefer them over client components.',
  'How have you handled performance bottlenecks in large-scale React applications?',
  'Walk me through a complex TypeScript generic you designed and why.',
  'How do you structure testing for component libraries?',
];

export default function CandidateProfile({ candidateId, onNavigate }: CandidateProfileProps) {
  const [activeTab, setActiveTab] = useState('Overview');
  const [shortlisted, setShortlisted] = useState(false);
  const candidate = candidates.find(c => c.id === candidateId) ?? candidates[0];

  const aiScores = {
    overall: candidate.aiScore,
    skills: Math.min(100, candidate.aiScore - 2),
    experience: Math.min(100, candidate.aiScore + 2),
    education: Math.min(100, candidate.aiScore - 5),
    culture: Math.min(100, candidate.aiScore - 3),
  };

  return (
    <div className="max-w-[1280px] mx-auto space-y-5 fade-in">
      {/* Back */}
      <button
        onClick={() => onNavigate('ranking')}
        className="flex items-center gap-1.5 text-sm text-zinc-500 hover:text-zinc-800 transition-colors"
      >
        <ArrowLeft size={14} />
        Back to Ranking
      </button>

      {/* Profile Header */}
      <div className="bg-white border border-zinc-200 rounded-xl p-6">
        <div className="flex items-start gap-5">
          {/* Avatar */}
          <div className={`size-16 rounded-2xl flex items-center justify-center text-xl font-bold flex-none ${candidate.color}`}>
            {candidate.initials}
          </div>

          {/* Info */}
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-3 flex-wrap">
              <h1 className="text-xl font-bold text-zinc-900">{candidate.name}</h1>
              <span className="px-2 py-0.5 bg-indigo-50 text-indigo-700 text-xs font-semibold rounded-md ring-1 ring-indigo-200">
                Shortlisted
              </span>
            </div>
            <p className="text-sm text-zinc-600 mt-0.5">{candidate.currentRole} · {candidate.company}</p>
            <div className="flex items-center gap-4 mt-2 flex-wrap">
              <span className="flex items-center gap-1 text-xs text-zinc-500">
                <MapPin size={11} />{candidate.location}
              </span>
              <span className="flex items-center gap-1 text-xs text-zinc-500">
                <Mail size={11} />{candidate.email}
              </span>
              <span className="flex items-center gap-1 text-xs text-zinc-500">
                <Phone size={11} />{candidate.phone}
              </span>
              <span className="flex items-center gap-1 text-xs text-indigo-600 hover:text-indigo-700 cursor-pointer">
                <Link size={11} />{candidate.linkedin}
              </span>
            </div>
          </div>

          {/* Actions */}
          <div className="flex items-center gap-2 flex-none">
            <button
              onClick={() => setShortlisted(!shortlisted)}
              className={`flex items-center gap-1.5 px-3 py-2 text-sm font-medium rounded-lg border transition-all ${
                shortlisted
                  ? 'bg-amber-50 text-amber-700 border-amber-200'
                  : 'bg-white text-zinc-700 border-zinc-200 hover:bg-zinc-50'
              }`}
            >
              <Star size={14} className={shortlisted ? 'fill-amber-500 text-amber-500' : ''} />
              {shortlisted ? 'Shortlisted' : 'Shortlist'}
            </button>
            <button className="flex items-center gap-1.5 px-3 py-2 text-sm font-medium text-white bg-indigo-600 rounded-lg hover:bg-indigo-700 transition-colors">
              <Calendar size={14} />
              Schedule Interview
            </button>
            <button className="flex items-center gap-1.5 px-3 py-2 text-sm font-medium text-zinc-700 bg-white border border-zinc-200 rounded-lg hover:bg-zinc-50 transition-colors">
              <MessageSquare size={14} />
              Send Email
            </button>
            <button className="flex items-center gap-1.5 px-3 py-2 text-sm font-medium text-red-600 bg-red-50 border border-red-200 rounded-lg hover:bg-red-100 transition-colors">
              <X size={14} />
              Reject
            </button>
          </div>
        </div>

        {/* Stats row */}
        <div className="flex items-center gap-6 mt-5 pt-5 border-t border-zinc-100">
          <div className="flex items-center gap-3">
            <ScoreRing score={candidate.aiScore} size="lg" />
            <div>
              <p className="text-xs font-semibold text-zinc-500 uppercase tracking-wide">AI Match</p>
              <p className="text-sm font-bold text-indigo-600 mt-0.5">
                {candidate.aiScore >= 90 ? 'Exceptional' : candidate.aiScore >= 80 ? 'Strong' : 'Good'}
              </p>
            </div>
          </div>
          <div className="h-10 w-px bg-zinc-100" />
          {[
            { label: 'Experience', value: `${candidate.experienceYears} yrs`, icon: Briefcase },
            { label: 'Skills', value: `${candidate.skills.length}`, icon: Award },
            { label: 'Education', value: `${candidate.education.length}`, icon: GraduationCap },
          ].map(({ label, value, icon: Icon }) => (
            <div key={label} className="flex items-center gap-2">
              <div className="size-8 rounded-lg bg-zinc-50 flex items-center justify-center">
                <Icon size={14} className="text-zinc-400" />
              </div>
              <div>
                <p className="text-xs text-zinc-500">{label}</p>
                <p className="text-sm font-bold text-zinc-900 font-mono">{value}</p>
              </div>
            </div>
          ))}
          <div className="ml-auto text-right">
            <p className="text-xs text-zinc-400">Applied {new Date(candidate.appliedDate).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}</p>
            <p className="text-xs text-zinc-400 mt-0.5">Source: {candidate.source}</p>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 border-b border-zinc-200 -mt-1">
        {tabs.map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`px-3 py-2 text-sm font-medium border-b-2 transition-all -mb-px ${
              activeTab === tab
                ? 'border-indigo-600 text-indigo-600'
                : 'border-transparent text-zinc-500 hover:text-zinc-800'
            }`}
          >
            {tab}
          </button>
        ))}
      </div>

      {/* Tab Content */}
      {activeTab === 'Overview' && (
        <div className="grid grid-cols-3 gap-4">
          <div className="col-span-2 space-y-4">
            {/* Summary */}
            <div className="bg-white border border-zinc-200 rounded-xl p-5">
              <h3 className="text-sm font-semibold text-zinc-800 mb-2">Professional Summary</h3>
              <p className="text-sm text-zinc-600 leading-relaxed">{candidate.summary}</p>
            </div>
            {/* Experience */}
            <div className="bg-white border border-zinc-200 rounded-xl p-5">
              <h3 className="text-sm font-semibold text-zinc-800 mb-4">Work Experience</h3>
              <div className="space-y-4">
                {candidate.experience.map((exp) => (
                  <div key={exp.role + exp.company} className="flex gap-3">
                    <div className="flex-none mt-0.5 size-7 rounded-lg bg-zinc-100 flex items-center justify-center">
                      <Briefcase size={13} className="text-zinc-400" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <p className="text-sm font-semibold text-zinc-900">{exp.role}</p>
                        <span className="text-xs text-zinc-400">·</span>
                        <p className="text-sm text-zinc-600">{exp.company}</p>
                        <span className="text-xs text-zinc-400 ml-auto font-mono">{exp.duration}</span>
                      </div>
                      <p className="text-xs text-zinc-500 mt-1 leading-relaxed">{exp.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-4">
            {/* Top Skills */}
            <div className="bg-white border border-zinc-200 rounded-xl p-4">
              <h3 className="text-sm font-semibold text-zinc-800 mb-3">Top Skills</h3>
              <div className="flex flex-wrap gap-1.5">
                {candidate.skills.map((s) => (
                  <span key={s} className="px-2 py-1 bg-zinc-100 text-zinc-700 text-xs font-medium rounded-md">
                    {s}
                  </span>
                ))}
              </div>
            </div>
            {/* Education */}
            <div className="bg-white border border-zinc-200 rounded-xl p-4">
              <h3 className="text-sm font-semibold text-zinc-800 mb-3">Education</h3>
              <div className="space-y-3">
                {candidate.education.map((edu) => (
                  <div key={edu.degree} className="flex gap-2.5">
                    <div className="flex-none mt-0.5 size-6 rounded-md bg-indigo-50 flex items-center justify-center">
                      <GraduationCap size={12} className="text-indigo-500" />
                    </div>
                    <div>
                      <p className="text-xs font-semibold text-zinc-900">{edu.degree}</p>
                      <p className="text-xs text-zinc-500">{edu.school} · {edu.year}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            {/* Details */}
            <div className="bg-white border border-zinc-200 rounded-xl p-4">
              <h3 className="text-sm font-semibold text-zinc-800 mb-3">Details</h3>
              <div className="space-y-2">
                {[
                  { label: 'Salary Expectation', value: candidate.salary },
                  { label: 'Notice Period', value: candidate.noticePeriod },
                  { label: 'Source', value: candidate.source },
                ].map(({ label, value }) => (
                  <div key={label} className="flex items-center justify-between">
                    <span className="text-xs text-zinc-400">{label}</span>
                    <span className="text-xs font-medium text-zinc-700">{value}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'AI Analysis' && (
        <div className="grid grid-cols-3 gap-4">
          <div className="col-span-2 space-y-4">
            {/* Score Overview */}
            <div className="bg-white border border-zinc-200 rounded-xl p-5">
              <div className="flex items-center gap-2 mb-5">
                <div className="size-6 rounded-md bg-violet-100 flex items-center justify-center">
                  <Sparkles size={13} className="text-violet-600" />
                </div>
                <h3 className="text-sm font-semibold text-zinc-900">AI Match Analysis</h3>
              </div>
              <div className="flex items-center gap-6 mb-6">
                <ScoreRing score={aiScores.overall} size="lg" />
                <div>
                  <p className="text-2xl font-bold text-zinc-900">{aiScores.overall}% Overall Match</p>
                  <p className="text-sm text-zinc-500 mt-0.5">
                    {aiScores.overall >= 90 ? 'Exceptional candidate — highly recommended' : 'Strong candidate for this role'}
                  </p>
                </div>
              </div>

              <div className="space-y-3">
                {[
                  { label: 'Skills Match', value: aiScores.skills, color: '#4f46e5' },
                  { label: 'Experience Match', value: aiScores.experience, color: '#7c3aed' },
                  { label: 'Education Match', value: aiScores.education, color: '#0ea5e9' },
                  { label: 'Culture / Role Fit', value: aiScores.culture, color: '#10b981' },
                ].map(({ label, value, color }) => (
                  <div key={label}>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-xs font-medium text-zinc-600">{label}</span>
                    </div>
                    <ProgressBar value={value} color={color} />
                  </div>
                ))}
              </div>
            </div>

            {/* AI Explanation */}
            <div className="bg-white border border-zinc-200 rounded-xl p-5">
              <h3 className="text-sm font-semibold text-zinc-900 mb-4">Why this candidate matches</h3>
              <div className="space-y-4">
                {[
                  {
                    title: 'Strengths',
                    items: ['Strong React and TypeScript expertise matching role requirements', 'Production experience at top-tier SaaS companies', 'Leadership and mentorship track record'],
                    icon: Check, iconCls: 'text-emerald-500', bgCls: 'bg-emerald-50',
                  },
                  {
                    title: 'Potential Concerns',
                    items: ['Salary expectations at top of budget range'],
                    icon: AlertTriangle, iconCls: 'text-amber-500', bgCls: 'bg-amber-50',
                  },
                ].map(({ title, items, icon: Icon, iconCls, bgCls }) => (
                  <div key={title}>
                    <p className="text-[10px] font-semibold uppercase tracking-widest text-zinc-400 mb-2">{title}</p>
                    <div className="space-y-1.5">
                      {items.map((item) => (
                        <div key={item} className={`flex items-start gap-2 p-2.5 rounded-lg ${bgCls}`}>
                          <Icon size={13} className={`flex-none mt-0.5 ${iconCls}`} />
                          <span className="text-xs text-zinc-700 leading-relaxed">{item}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Interview Questions */}
          <div className="space-y-4">
            <div className="bg-white border border-zinc-200 rounded-xl p-4">
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-sm font-semibold text-zinc-800">Recommended Questions</h3>
                <span className="text-[10px] text-violet-500 font-semibold">AI Generated</span>
              </div>
              <div className="space-y-2.5">
                {interviewQuestions.map((q, i) => (
                  <div key={i} className="flex gap-2">
                    <span className="text-[10px] font-mono font-bold text-zinc-300 mt-0.5 flex-none">
                      Q{i + 1}
                    </span>
                    <p className="text-xs text-zinc-600 leading-relaxed">{q}</p>
                  </div>
                ))}
              </div>
              <button className="mt-4 w-full flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-semibold text-violet-700 bg-violet-50 hover:bg-violet-100 rounded-lg transition-colors">
                <Sparkles size={12} />
                Generate More Questions
              </button>
            </div>

            <div className="p-4 bg-indigo-50 border border-indigo-100 rounded-xl">
              <div className="flex items-center gap-1.5 mb-2">
                <Sparkles size={13} className="text-indigo-500" />
                <p className="text-xs font-semibold text-indigo-700">AI Recommendation</p>
              </div>
              <p className="text-xs text-indigo-800 leading-relaxed">
                Highly recommended for technical interview. This candidate demonstrates exceptional alignment with role requirements and has proven experience at companies with similar engineering cultures.
              </p>
            </div>
          </div>
        </div>
      )}

      {(activeTab === 'Experience' || activeTab === 'Skills' || activeTab === 'Education' || activeTab === 'Interviews' || activeTab === 'Activity') && (
        <div className="bg-white border border-zinc-200 rounded-xl p-8 text-center">
          <div className="size-12 rounded-full bg-zinc-100 flex items-center justify-center mx-auto mb-3">
            <ChevronRight size={20} className="text-zinc-400" />
          </div>
          <p className="text-sm font-medium text-zinc-600">{activeTab} section</p>
          <p className="text-xs text-zinc-400 mt-1">Detailed {activeTab.toLowerCase()} information for {candidate.name}</p>
        </div>
      )}
    </div>
  );
}
